# document_task.py
from crew_ai.document_agent import Agent, Task

def create_extract_task(proposal_content: str):
    agent = Agent(
        name="Extractor",
        role="Requirement Extraction Specialist",
        goal="Extract key requirements, project scope, deadlines, and evaluation criteria.",
        backstory="Expert in analyzing RFPs and extracting structured requirements.",
        verbose=True
    )
    task = Task(
        description="Extract requirements, scope, deadlines, and evaluation criteria from the proposal.",
        expected_output="JSON with keyRequirements, projectScope, importantDeadlines, evaluationCriteria.",
        agent=agent
    )
    return task.run(inputs={"proposal_content": proposal_content, "instructions": task.description})

def create_summary_task(proposal_content: str):
    agent = Agent(
        name="Summarizer",
        role="Proposal Summarization Specialist",
        goal="Summarize the proposal into concise points.",
        backstory="Expert in reading large documents and summarizing them.",
        verbose=True
    )
    task = Task(
        description="Summarize the proposal clearly and concisely.",
        expected_output="JSON with summary.",
        agent=agent
    )
    return task.run(inputs={"proposal_content": proposal_content, "instructions": task.description})

def create_compliance_task(proposal_content: str):
    agent = Agent(
        name="ComplianceChecker",
        role="Compliance Analyst",
        goal="Check proposal compliance against RFP requirements.",
        backstory="Expert in compliance analysis and gap identification.",
        verbose=True
    )
    task = Task(
        description="Check compliance of the proposal and identify gaps.",
        expected_output="JSON with complianceReport.",
        agent=agent
    )
    return task.run(inputs={"proposal_content": proposal_content, "instructions": task.description})





from crewai import Task
from crew_ai.document_agent import capture

capture_task = Task(
    description=(
        "Research the {orgname} using public sources (official website, FPDS, GovWin, press releases, news, etc.) "
        "and generate a structured Intelligence Summary. "
        "Treat 'vTech Solution Inc' as the baseline company: we are vTech, so competitors are other firms likely to bid."
    ),
    expected_output=(
        "A JSON-compatible structured report containing:\n"
        "- 'clientProfile': { 'mission': str, 'strategicPriorities': [5 items], "
        "'technologyStrategy': str, 'leadership': [list of names/roles/urls] }\n"
        "- 'incumbentVendors': [6 dict rows with vendor, project, durationValue, performance, url]\n"
        "- 'competitors': [6 dict rows with firm, strengths, weaknesses, why they are bidding/likely to bid] "
        "(exclude vTech Solution Inc — vTech is the baseline for comparison)\n"
        "- 'gapAnalysis': [6 dict rows with item, currentState, gaps, desiredFutureState, url] "
        "(make gaps/future state relevant to vTech’s positioning)\n"
        "- 'stakeholders': [6 dict rows with name, role, relevance, remarks, url]"
    ),
    agent=capture
)




import os, json
from crewai import LLM

def extract_orgname(proposal_content: str) -> str:
    llm = LLM(
        model=f"azure/{os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')}",
        temperature=0,
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        base_url=os.getenv("AZURE_OPENAI_API_BASE"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    )
    prompt = (
        "Extract ONLY the issuing organization name from the RFP text below and return JSON "
        "{\"orgName\":\"...\"}.\n\n"
        f"{proposal_content[:2000]}"
    )
    # String or messages both supported by BaseLLM.call per docs
    out = llm.call(prompt)
    try:
        return json.loads(out)["orgName"].strip()
    except Exception:
        # find first JSON object if not valid
        import re
        m = re.search(r'\{[\s\S]*\}', out)
        if m:
            try:
                return json.loads(m.group(0))["orgName"].strip()
            except Exception:
                pass
        return out.strip()



