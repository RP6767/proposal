# document_task.py
from crew_ai.document_agent import Agent, Task
from crewai import Task
from crew_ai.agent import capture,outline_agent ,analyze_agent
import os, json
from crewai import LLM

def create_extract_task(proposal_content: str):
    agent = Agent(
        name="Extractor",
        role="Requirement Extraction Specialist",
        goal="Extract key requirements, project scope, deadlines, and evaluation criteria.",
        backstory="Expert in analyzing RFPs and extracting structured requirements.",
        verbose=True
    )
    task = Task(
        description="Extract requirements, scope, deadlines, and evaluation criteria from the proposal.",
        expected_output="JSON with keyRequirements, projectScope, importantDeadlines, evaluationCriteria.",
        agent=agent
    )
    return task.run(inputs={"proposal_content": proposal_content, "instructions": task.description})

def create_summary_task(proposal_content: str):
    agent = Agent(
        name="Summarizer",
        role="Proposal Summarization Specialist",
        goal="Summarize the proposal into concise points.",
        backstory="Expert in reading large documents and summarizing them.",
        verbose=True
    )
    task = Task(
        description="Summarize the proposal clearly and concisely.",
        expected_output="JSON with summary.",
        agent=agent
    )
    return task.run(inputs={"proposal_content": proposal_content, "instructions": task.description})

def create_compliance_task(proposal_content: str):
    agent = Agent(
        name="ComplianceChecker",
        role="Compliance Analyst",
        goal="Check proposal compliance against RFP requirements.",
        backstory="Expert in compliance analysis and gap identification.",
        verbose=True
    )
    task = Task(
        description="Check compliance of the proposal and identify gaps.",
        expected_output="JSON with complianceReport.",
        agent=agent
    )
    return task.run(inputs={"proposal_content": proposal_content, "instructions": task.description})
#crewai agent task--

capture_task = Task(
    description=(
        "Research the {orgname} using public sources (official website, FPDS, GovWin, press releases, news, etc.) "
        "and generate a structured Intelligence Summary. "
        "Treat 'vTech Solution Inc' as the baseline company: we are vTech, so competitors are other firms likely to bid."
    ),
    expected_output=(
        "A JSON-compatible structured report containing:\n"
        "- 'clientProfile': { 'mission': str, 'strategicPriorities': [5 items], "
        "'technologyStrategy': str, 'leadership': [list of names/roles/urls] }\n"
        "- 'incumbentVendors': [6 dict rows with vendor, project, durationValue, performance, url]\n"
        "- 'competitors': [6 dict rows with firm, strengths, weaknesses, whytheyarebidding] "
        "(exclude vTech Solution Inc — vTech is the baseline for comparison)\n"
        "- 'gapAnalysis': [6 dict rows with item, currentState, gaps, desiredFutureState, url] "
        "(make gaps/future state relevant to vTech’s positioning)\n"
        "- 'stakeholders': [6 dict rows with name, role, relevance, remarks, url]"
    ),
    agent=capture
)



analyze_task = Task(
    description=(
        "Analyze the provided proposal {content} to extract explicit information only. "
        "Focus on key requirements, project scope, important deadlines, and evaluation criteria. "
        "Do not infer, assume, or add extra information; return exactly what is present in the text."
    ),
    expected_output=(
        "Do not invent, assume, or add any information. "
        "If a section cannot be found in the text, return it as an empty list or empty string.\n\n"
        "Required output strictly as JSON with these keys:\n"
        "- 'keyRequirements': list of key requirements found in the proposal (use exactly what is present, do not generate extras).\n"
        "- 'projectScope': string containing the project scope (remove empty lines) and sure all data not miss any data from rfp and proposal content. If not present, return an empty string.\n"
        "- 'importantDeadlines': list of deadlines with dates and descriptions that are relevant to the project/proposal "
        "(e.g., submission dates, contract dates, delivery timelines,final sumbinssion,). "
        "Do NOT include unrelated or personal dates such as birthdays, anniversaries, or social events. "
        "If none are mentioned, return an empty list.\n"
        "- 'evaluationCriteria': list of evaluation criteria mentioned. If none are provided, return an empty list.\n\n"
        "The response must be strictly valid JSON and derived only from the input text."
    ),
    agent=analyze_agent
)



outline_task = Task(
    description=(
        "You are an APMP-certified Proposal Director supporting the vTech Solution proposal team in developing a high-scoring, compliant, and compelling response to a RFP"
        "You are given the full RFP content:\n\n{content}\n\n"
        "CREATE A COMPLETE PROPOSAL OUTLINE IN STRICT JSON FORMAT.\n"
        "JSON FORMAT MUST BE EXACTLY:\n"
        "{\n"
        "  'sections': [\n"
        "    {\n"
        "      'section_number': '1',\n"
        "      'title': 'Main Section Title',\n"
        "      'key_points': [\n"
        "          {\n"
        "              'sub_point_title': 'Subpoint title'\n"
        "          },\n"
        "          ... (as many subpoints as needed)\n"
        "      ]\n"
        "    },\n"
        "    ... (as many main sections as needed)\n"
        "  ]\n"
        "}\n\n"
        "Rules:\n"
        "1. Each major proposal section becomes one 'section' object.\n"
        "2. Each section can have multiple subpoints under 'key_points'.\n"
        "3. Subpoints only include 'sub_point_title'. Do NOT include details or description.\n"
        "4. The output must represent a realistic, professional proposal.\n"
        "5. Typical sections include:Make section and sub-section according to you\n"
        "6. Subpoints should be meaningful.\n"
        "7. Do NOT add prose or explanation outside the JSON. Only output the JSON."
    ),
    expected_output=(
        "A strict JSON object representing a fully populated proposal outline "
        "with main sections and multiple realistic subpoints per section."
    ),
    agent=outline_agent,
)






def extract_orgname(proposal_content: str) -> str:
    llm = LLM(
        model=f"azure/{os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')}",
        temperature=0,
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        base_url=os.getenv("AZURE_OPENAI_API_BASE"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    )
    prompt = (
        "Extract ONLY the issuing organization name from the RFP text below and return JSON "
        "{\"orgName\":\"...\"}.\n\n"
        f"{proposal_content[:2000]}"
    )
    # String or messages both supported by BaseLLM.call per docs
    out = llm.call(prompt)
    try:
        return json.loads(out)["orgName"].strip()
    except Exception:
        # find first JSON object if not valid
        import re
        m = re.search(r'\{[\s\S]*\}', out)
        if m:
            try:
                return json.loads(m.group(0))["orgName"].strip()
            except Exception:
                pass
        return out.strip()



