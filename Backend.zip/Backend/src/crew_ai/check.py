# check.py
from tools import google_search, website_scraper

if __name__ == "__main__":
    query = "Owens Valley Career Development Center official site"

    print("🔍 Testing google_search.func():")
    result = google_search.func(query)   # direct call to the wrapped function
    print(result)

    print("\n🌐 Testing google_search.run():")
    result = google_search.run(query)    # CrewAI-style call
    print(result)

    # Optional test for website scraper
    print("\n🧭 Testing website_scraper:")
    url = "https://www.ovcdc.com/"
    print(website_scraper.func(url))
