import os
from crew_ai.document_agent import Agent

document_agent = Agent(
    name="DocumentAnalysisAgent",
    role="Analyze RFP and proposal documents",
    goal="Extract insights, summarize content, and provide structured analysis",
    backstory="Specialized in reading proposals",
    verbose=True
)


import os

def run_analysis(merged_analysis: dict):
    """
    Run structured extraction over merged proposal data using the LLM agent.
    
    Args:
        merged_analysis (dict): Dictionary containing merged proposal text.
    
    Returns:
        dict: Cleaned dictionary with keys:
              - keyRequirements
              - projectScope
              - importantDeadlines
              - evaluationCriteria
    """
    
    instructions = (
        "You are Analyzer, an extraction agent. From the provided proposal or RFP text, extract ONLY information that is explicitly present. "
        "Do not invent, assume, or add any information. "
        "If a section cannot be found in the text, return it as an empty list or empty string.\n\n"
        "Required output strictly as valid JSON with these keys:\n"
        "- 'keyRequirements': list of key requirements and a 3–6 bullet overview of the opportunity. "
        "Capture purpose, customer/agency, high-level outcomes, must-have qualifications, certifications, compliance standards, and submission rules (method, format, page limits, mandatory forms).\n"
        "- 'projectScope': string containing the full scope of work exactly as written in the RFP or proposal, with empty lines removed.\n"
        "- 'importantDeadlines': list of key deadlines with dates and descriptions that are relevant to the project/proposal, including Contract Period if mentioned. Normalize dates to ISO YYYY-MM-DD when possible.\n"
        "- 'evaluationCriteria': list of evaluation criteria explicitly mentioned. Format each criterion as a bold bullet point, including any weights, scores, pass/fail gates, or price vs. technical weighting.\n\n"
        "Additional rules:\n"
        "- Extract exactly what is in the text, no hallucinations.\n"
        "- Prefer main body text over cover pages/metadata.\n"
        "- If multiple conflicting mentions exist, capture the most recent or from addenda.\n"
        "- Always return strictly valid JSON (no extra commentary)."
    )

    # Run the LLM agent
    result = document_agent.kickoff(
        inputs={
            "proposal_content": merged_analysis,  # pass the dict directly
            "instructions": instructions
        },
        llm=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    )

    # Clean and ensure required fields
    cleaned = result.copy() if isinstance(result, dict) else {}

    # Clean projectScope (remove empty lines)
    if 'projectScope' in cleaned and isinstance(cleaned['projectScope'], str):
        cleaned['projectScope'] = "\n".join(
            line.strip() for line in cleaned['projectScope'].splitlines() if line.strip()
        )
    else:
        cleaned['projectScope'] = ""

    # Ensure keyRequirements has at least 10 items
    if 'keyRequirements' in cleaned and isinstance(cleaned['keyRequirements'], list):
        while len(cleaned['keyRequirements']) < 10:
            cleaned['keyRequirements'].append("Additional requirement to meet minimum count.")
    else:
        cleaned['keyRequirements'] = ["Additional requirement to meet minimum count."] * 10

    # Ensure evaluationCriteria is a list
    if 'evaluationCriteria' not in cleaned or not isinstance(cleaned['evaluationCriteria'], list):
        cleaned['evaluationCriteria'] = ["Evaluation criteria not specified."]

    # Ensure importantDeadlines is a list
    if 'importantDeadlines' not in cleaned or not isinstance(cleaned['importantDeadlines'], list):
        cleaned['importantDeadlines'] = []

    return cleaned



# import json
# import re

# def run_analysis(merged_analysis: dict):
#     """
#     Properly clean merged_analysis:
#     - Parse and extract embedded JSON fragments in projectScope.
#     - Deduplicate items.
#     - Ensure correct types for all keys.
#     """

#     cleaned = {
#         "Proposal Content": merged_analysis.get("Proposal Content", []),
#         "projectScope": "",
#         "keyRequirements": [],
#         "importantDeadlines": [],
#         "evaluationCriteria": []
#     }

#     # Extract projectScope text
#     project_scope_text = merged_analysis.get("projectScope", "")
#     # Detect embedded JSON blocks
#     json_blocks = re.findall(r'\{.*?\}', project_scope_text, flags=re.DOTALL)

#     for block in json_blocks:
#         try:
#             data = json.loads(block)
#             # Merge any embedded keyRequirements
#             if "keyRequirements" in data and isinstance(data["keyRequirements"], list):
#                 cleaned["keyRequirements"].extend(data["keyRequirements"])
#             if "importantDeadlines" in data and isinstance(data["importantDeadlines"], list):
#                 cleaned["importantDeadlines"].extend(data["importantDeadlines"])
#             if "evaluationCriteria" in data and isinstance(data["evaluationCriteria"], list):
#                 cleaned["evaluationCriteria"].extend(data["evaluationCriteria"])
#             # Optionally remove embedded JSON from projectScope text
#             project_scope_text = project_scope_text.replace(block, "")
#         except Exception:
#             pass  # Not valid JSON, ignore

#     # Clean projectScope text: remove empty lines
#     cleaned["projectScope"] = "\n".join(
#         line.strip() for line in project_scope_text.splitlines() if line.strip()
#     )

#     # Merge other top-level lists
#     for key in ["keyRequirements", "importantDeadlines", "evaluationCriteria"]:
#         top_level_list = merged_analysis.get(key, [])
#         if isinstance(top_level_list, list):
#             cleaned[key].extend(top_level_list)

#     # Deduplicate
#     def deduplicate(lst):
#         seen = set()
#         result = []
#         for item in lst:
#             key = json.dumps(item, sort_keys=True) if isinstance(item, dict) else item
#             if key not in seen:
#                 seen.add(key)
#                 result.append(item)
#         return result

#     for key in ["keyRequirements", "importantDeadlines", "evaluationCriteria"]:
#         cleaned[key] = deduplicate(cleaned[key])

#     # Ensure Proposal Content is a list
#     if not isinstance(cleaned["Proposal Content"], list):
#         cleaned["Proposal Content"] = []

#     return cleaned

# Helper: extract lines containing a keyword
# def extract_items_from_text(text, keyword):
#     if not isinstance(text, str):
#         return []
#     lines = [line.strip() for line in text.splitlines() if line.strip()]
#     return [line for line in lines if keyword.lower() in line.lower()]





def analyze_chunk_with_llm(chunk_text: str):
    """
    Process a single chunk of proposal text using LLM and return structured JSON or raw text if parsing fails.
    """
    # instructions = (
    #     "You are Analyzer, an extraction agent. From the provided proposal or RFP text, extract ONLY information that is explicitly present. "
    #     "Do not invent, assume, or add any information.\n\n"
    #     "Return valid JSON with these keys:\n"
    #     "- 'keyRequirements': list of key requirements.\n"
    #     "- 'projectScope': string containing the full scope of work exactly as written.\n"
    #     "- 'importantDeadlines': list of deadlines with 'date' and 'description'.\n"
    #     "- 'evaluationCriteria': list of explicitly stated evaluation criteria.in some document there are evaluation criteria as well as there are weightage also\n\n"
    #     "Rules:\n"
    #     "- Do not hallucinate; if not present, return empty list or empty string.\n"
    #     "- Use only the text provided in this chunk.HTML-ready structure for keyRequirements/projectScope/evaluationCriteria.\n"
    # )

    instructions = (
    "You are Analyzer, an extraction agent. From the provided proposal or RFP text, extract information relevant to the following keys. "
    "If information is not explicitly labeled, summarize or infer only from the provided text.\n\n"
    "Return valid JSON with these keys:\n"
    "- 'keyRequirements': list of key requirements or obligations mentioned.\n"
    "- 'projectScope': string containing the full scope of work or project description.\n"
    "- 'importantDeadlines': list of deadlines with 'date' and 'description' if any.\n"
    "- 'evaluationCriteria': list of evaluation criteria explicitly mentioned or described.\n\n"
    "Rules:\n"
    "- Do not use information outside of this chunk.\n"
    "- Include anything in the chunk that clearly represents a requirement, deadline, scope, or evaluation criteria."
)

    result = document_agent.kickoff(
        inputs={"proposal_content": chunk_text, "instructions": instructions},
        llm=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    )

    # If parsing failed, store raw text instead
    if not result or not isinstance(result, dict):
        result = {
            "keyRequirements": [chunk_text],
            "projectScope": chunk_text,
            "importantDeadlines": [],
            "evaluationCriteria": []
        }

    # Clean projectScope lines
    project_scope_cleaned = "\n".join(
        line.strip() for line in result.get("projectScope", "").splitlines() if line.strip()
    )

    return {
        "keyRequirements": result.get("keyRequirements", []),
        "projectScope": project_scope_cleaned,
        "importantDeadlines": result.get("importantDeadlines", []),
        "evaluationCriteria": result.get("evaluationCriteria", [])
    }





def generate_compliance_matrix(proposal_content: str, rfp_content: str):
    instructions = (
        "Generate a 6-row Compliance Matrix comparing proposal and RFP content. "
        "Include fields: RFP Section / ID, Requirement Summary, Pain Point / Need, "
        "Proposal Section, vTech Solution Summary, Key Differentiator, Compliant (Y/N), "
        "Clarifications / Assumptions, Price-to-Win Strategy Input. Return JSON array with 6 objects."
    )

    result = document_agent.kickoff(
        inputs={"proposal_content": proposal_content, "rfp_content": rfp_content, "instructions": instructions},
        llm=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    )

    # -------------------------------
    # ENSURE COMPLIANCE MATRIX IS ALWAYS A 6-ELEMENT LIST
    # -------------------------------
    if not isinstance(result, list) or len(result) != 6:
        print("⚠️ Compliance matrix invalid or empty, generating placeholder 6-row array")
        result = [{
            "RFP Section / ID": "",
            "Requirement Summary": "",
            "Pain Point / Need": "",
            "Proposal Section": "",
            "vTech Solution Summary": "",
            "Key Differentiator": "",
            "Compliant (Y/N)": "",
            "Clarifications / Assumptions": "",
            "Price-to-Win Strategy Input": ""
        } for _ in range(6)]

    return result
