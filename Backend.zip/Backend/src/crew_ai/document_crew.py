import os
from crew_ai.document_agent import Agent

document_agent = Agent(
    name="DocumentAnalysisAgent",
    role="Analyze RFP and proposal documents",
    goal="Extract insights, summarize content, and provide structured analysis",
    backstory="Specialized in reading proposals",
    verbose=True
)

def run_analysis(proposal_content: str):
    instructions = (
        "Extract the following from the proposal text:\n"
        "- Key Requirements (list, at least 10 items)\n"
        "- Project Scope (text, remove empty lines, at least 200 words)\n"
        "- Important Deadlines (list with dates and descriptions)\n"
        "- Evaluation Criteria (list, multiple points)\n"
        "Return strictly as JSON with keys: "
        "'keyRequirements', 'projectScope', 'importantDeadlines', 'evaluationCriteria'."
    )
    result = document_agent.kickoff(
        inputs={"proposal_content": proposal_content, "instructions": instructions},
        llm=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    )

    # Clean and ensure required fields
    cleaned = result.copy()
    if 'projectScope' in cleaned:
        cleaned['projectScope'] = "\n".join(line.strip() for line in cleaned['projectScope'].splitlines() if line.strip())
    if 'keyRequirements' in cleaned:
        while len(cleaned['keyRequirements']) < 10:
            cleaned['keyRequirements'].append("Additional requirement to meet minimum count.")
    if 'evaluationCriteria' not in cleaned or not isinstance(cleaned['evaluationCriteria'], list):
        cleaned['evaluationCriteria'] = ["Evaluation criteria not specified."]
    return cleaned


def generate_compliance_matrix(proposal_content: str, rfp_content: str):
    instructions = (
        "Generate a 6-row Compliance Matrix comparing proposal and RFP content. "
        "Include fields: RFP Section / ID, Requirement Summary, Pain Point / Need, "
        "Proposal Section, vTech Solution Summary, Key Differentiator, Compliant (Y/N), "
        "Clarifications / Assumptions, Price-to-Win Strategy Input. Return JSON array with 6 objects."
    )

    result = document_agent.kickoff(
        inputs={"proposal_content": proposal_content, "rfp_content": rfp_content, "instructions": instructions},
        llm=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    )

    # -------------------------------
    # ENSURE COMPLIANCE MATRIX IS ALWAYS A 6-ELEMENT LIST
    # -------------------------------
    if not isinstance(result, list) or len(result) != 6:
        print("⚠️ Compliance matrix invalid or empty, generating placeholder 6-row array")
        result = [{
            "RFP Section / ID": "",
            "Requirement Summary": "",
            "Pain Point / Need": "",
            "Proposal Section": "",
            "vTech Solution Summary": "",
            "Key Differentiator": "",
            "Compliant (Y/N)": "",
            "Clarifications / Assumptions": "",
            "Price-to-Win Strategy Input": ""
        } for _ in range(6)]

    return result
