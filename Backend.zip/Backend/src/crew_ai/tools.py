# import requests
# from bs4 import BeautifulSoup
# from duckduckgo_search import DDGS

# def google_search(query: str) -> str:
#     """Search the web for public information (press releases, audits, IT roadmaps, procurement)."""
#     try:
#         results = []
#         with DDGS() as ddgs:
#             for r in ddgs.text(query, max_results=5):
#                 results.append(f"- {r['title']} ({r['href']})\n{r['body']}")
#         return "\n\n".join(results) if results else "No results found."
#     except Exception as e:
#         return f"Search error: {e}"


# def website_scraper(url: str) -> str:
#     """Fetch raw text from a public URL (procurement portal, IT roadmap, press release)."""
#     try:
#         response = requests.get(url, timeout=15)
#         response.raise_for_status()
#         soup = BeautifulSoup(response.text, "html.parser")
#         for s in soup(["script", "style"]):
#             s.decompose()
#         text = soup.get_text(separator="\n")
#         clean_text = "\n".join([line.strip() for line in text.splitlines() if line.strip()])
#         return clean_text[:5000]
#     except Exception as e:
#         return f"Scraper error: {e}"

# tools.py
import requests
from bs4 import BeautifulSoup
from ddgs import DDGS
from crewai.tools import tool

@tool("google_search")
def google_search(query: str) -> str:
    """Search the web for public information (press releases, audits, IT roadmaps, procurement)."""
    try:
        results = []
        with DDGS() as ddgs:
            for r in ddgs.text(query, max_results=5):
                results.append(f"- {r['title']} ({r['href']})\n{r['body']}")
        return "\n\n".join(results) if results else "No results found."
    except Exception as e:
        return f"Search error: {e}"


@tool("website_scraper")
def website_scraper(url: str) -> str:
    """Fetch raw text from a public URL (procurement portal, IT roadmap, press release)."""
    import requests
    from bs4 import BeautifulSoup

    try:
        response = requests.get(url, timeout=15)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        for s in soup(["script", "style"]):
            s.decompose()
        text = soup.get_text(separator="\n")
        clean_text = "\n".join([line.strip() for line in text.splitlines() if line.strip()])
        return clean_text[:5000]
    except Exception as e:
        return f"Scraper error: {e}"



@tool("intelligent_search")
def intelligent_search(query: str) -> str:
    """Performs a search, then automatically scrapes the top official site if found."""
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=5))

        if not results:
            return "No search results found."

        # Look for the first official-looking website
        main_url = None
        for r in results:
            href = r.get("href", "")
            if "official" in r.get("body", "").lower() or "www." in href:
                main_url = href
                break

        summary = "\n\n".join(f"- {r['title']} ({r['href']})\n{r['body']}" for r in results[:3])

        if main_url:
            scraped = website_scraper.func(main_url)
            return f"🔎 **Top Search Results:**\n{summary}\n\n🌐 **Scraped Content from {main_url}:**\n{scraped[:3000]}"
        else:
            return f"🔎 **Top Search Results:**\n{summary}"

    except Exception as e:
        return f"Search error: {e}"



TOOLS = [google_search, website_scraper, intelligent_search]



