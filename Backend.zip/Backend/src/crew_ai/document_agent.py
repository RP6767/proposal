# src/crew_ai/document_agent.py
import json
import os
import openai
from dotenv import load_dotenv
from crewai import Agent as CrewAgent, LLM

load_dotenv()

# -----------------------------
# Azure OpenAI config
# -----------------------------
openai.api_key = os.getenv("AZURE_OPENAI_API_KEY")
openai.api_base = os.getenv("AZURE_OPENAI_API_BASE")  # e.g., https://vtazopenai.openai.azure.com/
openai.api_type = "azure"
openai.api_version = os.getenv("AZURE_OPENAI_API_VERSION")  # e.g., 2025-01-01-preview


# class Agent:
#     def __init__(self, name=None, role=None, goal=None, backstory=None, verbose=False):
#         self.name = name or "Agent"
#         self.role = role
#         self.goal = goal
#         self.backstory = backstory
#         self.verbose = verbose

#     def kickoff(self, inputs=None, llm=None):
#         """
#         Run the agent using Azure OpenAI. Automatically truncates content if too long.
#         """
#         if inputs is None:
#             inputs = {}

#         proposal_content = inputs.get("proposal_content", "")
#         instructions = inputs.get("instructions", "")

#         if self.verbose:
#             print(f"[{self.name}] kickoff called. Content length: {len(proposal_content)}")

#         # Truncate to prevent token overflow (safe ~15k characters for gpt-35-turbo)
#         MAX_CHARS = 15000
#         if len(proposal_content) > MAX_CHARS:
#             proposal_content = proposal_content[:MAX_CHARS] + "\n...[truncated]"
#             if self.verbose:
#                 print(f"[{self.name}] Content truncated to {MAX_CHARS} characters")

#         prompt_text = f"{instructions}\n\nProposal Content:\n{proposal_content}"

#         try:
#             response = openai.chat.completions.create(
#                 model=llm,
#                 messages=[
#                     {"role": "system", "content": "You are an assistant helping with RFP analysis."},
#                     {"role": "user", "content": prompt_text}
#                 ],
#                 max_tokens=1000,
#                 temperature=0.2
#             )

#             raw_output = response.choices[0].message.content

#             try:
#                 analysis_json = json.loads(raw_output)
#             except Exception:
#                 print(f"[{self.name}] ⚠️ Could not parse JSON, returning empty structure")
#                 analysis_json = {
#                     "keyRequirements": [raw_output],
#                     "projectScope": raw_output,
#                     "importantDeadlines": [],
#                     "evaluationCriteria": []
#                 }

#             return analysis_json

#         except Exception as e:
#             print(f"[{self.name}] ⚠️ LLM analysis failed: {e}")
#             return {
#                 "keyRequirements": [],
#                 "projectScope": "",
#                 "importantDeadlines": [],
#                 "evaluationCriteria": [],
#                 "error": str(e)
#             }



import json
import re
import openai

def safe_json_loads(raw_output):
    """
    Safely parse JSON output. 
    If parsing fails, try to extract the JSON block. 
    If still invalid, return an empty schema.
    """
    schema = {
        "keyRequirements": [],
        "projectScope": "",
        "importantDeadlines": [],
        "evaluationCriteria": []
    }

    # First attempt: direct parse
    try:
        return json.loads(raw_output)
    except Exception:
        pass

    # Second attempt: extract JSON substring
    match = re.search(r"\{.*\}", raw_output, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except Exception:
            pass

    # Last resort: return default schema
    return schema


class Agent:
    def __init__(self, name=None, role=None, goal=None, backstory=None, verbose=False):
        self.name = name or "Agent"
        self.role = role
        self.goal = goal
        self.backstory = backstory
        self.verbose = verbose

    def kickoff(self, inputs=None, llm=None):
        """
        Run the agent using Azure OpenAI. Automatically truncates content if too long.
        """
        if inputs is None:
            inputs = {}

        proposal_content = inputs.get("proposal_content", "")
        instructions = inputs.get("instructions", "")

        if self.verbose:
            print(f"[{self.name}] kickoff called. Content length: {len(proposal_content)}")

        # Truncate to prevent token overflow (safe ~15k characters for gpt-35-turbo)
        MAX_CHARS = 15000
        if len(proposal_content) > MAX_CHARS:
            proposal_content = proposal_content[:MAX_CHARS] + "\n...[truncated]"
            if self.verbose:
                print(f"[{self.name}] Content truncated to {MAX_CHARS} characters")

        prompt_text = f"{instructions}\n\nProposal Content:\n{proposal_content}"

        try:
            response = openai.chat.completions.create(
                model=llm,
                messages=[
                    {"role": "system", "content": "You are an assistant helping with RFP analysis."},
                    {"role": "user", "content": prompt_text}
                ],
                max_tokens=1000,
                temperature=0.2
            )

            raw_output = response.choices[0].message.content

            # ✅ Always return structured JSON
            analysis_json = safe_json_loads(raw_output)
            return analysis_json

        except Exception as e:
            print(f"[{self.name}] ⚠️ LLM analysis failed: {e}")
            return {
                "keyRequirements": [],
                "projectScope": "",
                "importantDeadlines": [],
                "evaluationCriteria": [],
                "error": str(e)
            }
# -----------------------------
# Capture Agent Setup
# -----------------------------

# Prefer Azure-style envs, fall back to common aliases



# -----------------------------
# Task Wrapper
# -----------------------------

class Task:
    def __init__(self, description, expected_output, agent: Agent):
        self.description = description
        self.expected_output = expected_output
        self.agent = agent

    def run(self, inputs):
        return self.agent.kickoff(inputs=inputs)
