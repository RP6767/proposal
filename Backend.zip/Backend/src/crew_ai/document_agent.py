#document_agent.py
import json
import os
import openai
from dotenv import load_dotenv

load_dotenv()

openai.api_key = os.getenv("AZURE_OPENAI_API_KEY")
openai.api_base = os.getenv("AZURE_OPENAI_API_BASE")
openai.api_type = "azure"
openai.api_version = os.getenv("AZURE_OPENAI_API_VERSION")

class Agent:
    def __init__(self, name=None, role=None, goal=None, backstory=None, verbose=False):
        self.name = name or "Agent"
        self.role = role
        self.goal = goal
        self.backstory = backstory
        self.verbose = verbose

    def kickoff(self, inputs=None, llm=None):
        if inputs is None:
            inputs = {}
        proposal_content = inputs.get("proposal_content", "")
        instructions = inputs.get("instructions", "")
        rfp_content = inputs.get("rfp_content", "")

        if self.verbose:
            print(f"[{self.name}] kickoff called. Content length: {len(proposal_content)}")

        MAX_CHARS = 15000
        if len(proposal_content) > MAX_CHARS:
            proposal_content = proposal_content[:MAX_CHARS] + "\n...[truncated]"

        prompt_text = f"{instructions}\n\nProposal Content:\n{proposal_content}"
        if rfp_content:
            prompt_text += f"\n\nRFP Content:\n{rfp_content}"

        try:
            response = openai.chat.completions.create(
                model=llm,
                messages=[
                    {"role": "system", "content": "You are an assistant helping with RFP analysis."},
                    {"role": "user", "content": prompt_text}
                ],
                max_tokens=1500,
                temperature=0.2
            )

            raw_output = response.choices[0].message.content
            try:
                return json.loads(raw_output)
            except Exception:
                if self.verbose:
                    print(f"[{self.name}] ⚠️ Could not parse JSON, returning empty structure")
                return {}

        except Exception as e:
            if self.verbose:
                print(f"[{self.name}] ⚠️ LLM analysis failed: {e}")
            return {"error": str(e)}


class Task:
    def __init__(self, description, expected_output, agent: Agent):
        self.description = description
        self.expected_output = expected_output
        self.agent = agent

    def run(self, inputs):
        return self.agent.kickoff(inputs=inputs)


def create_compliance_matrix_task(proposal_content: str, rfp_content: str):
    agent = Agent(
        name="ComplianceMatrixGenerator",
        role="Compliance Analyst",
        goal="Compare proposal against RFP and produce a 6-row Compliance Matrix.",
        backstory="Expert in compliance analysis, gap identification, and proposal evaluation.",
        verbose=True
    )

    description = (
        "Review the provided RFP content and proposal content. "
        "Generate a Compliance Matrix with exactly 6 rows and the following fields: "
        "RFP Section / ID, Requirement Summary, Pain Point / Need, Proposal Section, "
        "vTech Solution Summary, Key Differentiator, Compliant (Y/N), "
        "Clarifications / Assumptions, Price-to-Win Strategy Input. "
        "Return strictly JSON array with 6 objects."
    )

    task = Task(description, expected_output="JSON array with 6 objects", agent=agent)
    return task.run(inputs={
        "proposal_content": proposal_content,
        "rfp_content": rfp_content,
        "instructions": description
    })


from crewai import Agent, LLM
import os
from dotenv import load_dotenv

load_dotenv()

# Prefer Azure-style envs, fall back to common aliases
deployment = (
    os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    or os.getenv("OPENAI_DEPLOYMENT_NAME")
)
api_key = (
    os.getenv("AZURE_OPENAI_API_KEY")
    or os.getenv("AZURE_API_KEY")
    or os.getenv("OPENAI_API_KEY")
)
api_base = (
    os.getenv("AZURE_OPENAI_API_BASE")
    or os.getenv("AZURE_API_BASE")
    or os.getenv("OPENAI_API_BASE")
    or os.getenv("AZURE_OPENAI_ENDPOINT")  # fallback if only endpoint is set
)
api_version = (
    os.getenv("AZURE_OPENAI_API_VERSION")
    or os.getenv("AZURE_API_VERSION")
    or os.getenv("OPENAI_API_VERSION")
)

assert deployment, "Missing deployment name (AZURE_OPENAI_DEPLOYMENT_NAME or OPENAI_DEPLOYMENT_NAME)"
assert api_key, "Missing Azure API key (AZURE_OPENAI_API_KEY or AZURE_API_KEY or OPENAI_API_KEY)"
assert api_base, "Missing Azure API base (AZURE_OPENAI_API_BASE or AZURE_API_BASE or OPENAI_API_BASE)"
assert api_version, "Missing Azure API version (AZURE_OPENAI_API_VERSION or AZURE_API_VERSION or OPENAI_API_VERSION)"

llm = LLM(
    model=f"azure/{deployment}",   # e.g., azure/gpt-35-turbo
    temperature=0.2,
    api_key=api_key,
    base_url=api_base,             # e.g., https://<resource>.openai.azure.com/
    api_version=api_version        # e.g., 2024-02-15-preview
    # provider inferred from "azure/" prefix
)

capture = Agent(
    role="AI Capture Analyst for vTech Solution Family inc",
    goal=(
        "Generate an Intelligence Summary for a {orgname} using only public sources "
        "(press releases, strategic plans, procurement portals, IT modernization reports, LinkedIn, audits, market research)."
    ),
    verbose=True,
    memory=True,
    backstory=(
        "You are an experienced capture analyst of vTech solution inc focused on public-sector modernization opportunities. "
        "Only use publicly-available information from web searches and official websites. "
        "Always produce structured outputs: client profile, incumbent vendors, competitors, gap analysis, stakeholders."
    ),
    llm=llm,
    allow_delegation=True
)
