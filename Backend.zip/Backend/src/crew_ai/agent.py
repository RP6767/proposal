from crewai import Agent, LLM
import os
from dotenv import load_dotenv
from crew_ai.tools import TOOLS

load_dotenv()

# Prefer Azure-style envs, fall back to common aliases
deployment = (
    os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    or os.getenv("OPENAI_DEPLOYMENT_NAME")
)
api_key = (
    os.getenv("AZURE_OPENAI_API_KEY")
    or os.getenv("AZURE_API_KEY")
    or os.getenv("OPENAI_API_KEY")
)
api_base = (
    os.getenv("AZURE_OPENAI_API_BASE")
    or os.getenv("AZURE_API_BASE")
    or os.getenv("OPENAI_API_BASE")
    or os.getenv("AZURE_OPENAI_ENDPOINT")  # fallback if only endpoint is set
)
api_version = (
    os.getenv("AZURE_OPENAI_API_VERSION")
    or os.getenv("AZURE_API_VERSION")
    or os.getenv("OPENAI_API_VERSION")
)

assert deployment, "Missing deployment name (AZURE_OPENAI_DEPLOYMENT_NAME or OPENAI_DEPLOYMENT_NAME)"
assert api_key, "Missing Azure API key (AZURE_OPENAI_API_KEY or AZURE_API_KEY or OPENAI_API_KEY)"
assert api_base, "Missing Azure API base (AZURE_OPENAI_API_BASE or AZURE_API_BASE or OPENAI_API_BASE)"
assert api_version, "Missing Azure API version (AZURE_OPENAI_API_VERSION or AZURE_API_VERSION or OPENAI_API_VERSION)"

llm = LLM(
    model=f"azure/{deployment}",   # e.g., azure/gpt-35-turbo
    temperature=0.2,
    api_key=api_key,
    base_url=api_base,             # e.g., https://<resource>.openai.azure.com/
    api_version=api_version        # e.g., 2024-02-15-preview
    # provider inferred from "azure/" prefix
)


from crew_ai.tools import TOOLS




analyze_agent= Agent(
    role="Proposal Content Analysis Specialist",
    goal=(
        "Analyze the provided {content} proposal and RFP content to extract explicit information only. "
        "Focus on key requirements, project scope, important deadlines, and evaluation criteria. "
        "Do not infer, assume, or add any extra information; return only what is present in the text."
    ),
    backstory=(
        "You are a detail-oriented APMP-certified Proposal Analyst. "
        "Your responsibility is to extract structured, evaluator-ready data strictly from the proposal "
        "and RFP text. Accuracy and completeness of the explicit data is critical."
    ),
    llm=llm,
    allow_delegation=False,
    verbose=True,
)

capture = Agent(
    role="AI Capture Analyst for vTech Solution Family inc",
    goal=(
        "Generate an Intelligence Summary for a {orgname} using only public sources "
        "(press releases, strategic plans, procurement portals, IT modernization reports, LinkedIn, audits, market research)."
    ),
    verbose=True,
    memory=True,
    backstory=(
        "You are an experienced capture analyst of vTech solution inc focused on public-sector modernization opportunities. "
        "Only use publicly-available information from web searches and official websites. "
        "Always produce structured outputs: client profile, incumbent vendors, competitors, gap analysis, stakeholders."
    ),
    llm=llm,
    allow_delegation=True,
    tools=TOOLS
)


outline_agent = Agent(
    role="Proposal Outline & Solution Guidance Architect",
    goal=(
        "Develop a Proposal Outline Framework that mirrors the RFP exactly and provides strategic solution guidance. "
        "For each section, extract the exact RFP section number/title, summarize compliance requirements, "
        "and provide vTech-specific guidance using capture insights, client pain points, and win themes."
    ),
    backstory=(
        "You are an APMP-certified Proposal Director supporting the vTech Solution proposal team. "
        "Your role is to translate the RFP into a structured, evaluator-friendly outline "
        "with solution guidance tailored to vTech’s differentiators, past performance, and credentials."
    ),
    llm=llm,
    allow_delegation=False,
    verbose=True,
)