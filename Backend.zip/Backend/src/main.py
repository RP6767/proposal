# src/main.py
import os
import json
import re
import requests
from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime, timezone
from dotenv import load_dotenv
import firebase_admin
from firebase_admin import credentials, firestore
from bs4 import BeautifulSoup  # for URL text extraction
import PyPDF2
import docx
from crew_ai.document_crew import run_analysis
from crew_ai.document_crew import generate_compliance_matrix
import asyncio
from concurrent.futures import ThreadPoolExecutor
import uuid
from urllib.parse import unquote
from threading import Thread
from itertools import zip_longest


# -----------------------------
# Load environment variables
# -----------------------------
load_dotenv()

# -----------------------------
# Initialize Flask app
# -----------------------------
app = Flask(__name__)
CORS(app)

# -----------------------------
# Initialize Firebase
# -----------------------------
try:
    service_account_info = json.loads(os.getenv("FIREBASE_SERVICE_ACCOUNT"))
    cred = credentials.Certificate(service_account_info)
    firebase_admin.initialize_app(cred)
    db = firestore.client()
    print("✅ Firebase initialized successfully.")
except Exception as e:
    print("❌ Firebase initialization failed:", e)
    db = None

# -----------------------------
# Azure OpenAI Setup
# -----------------------------
AZURE_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_API_BASE = os.getenv("AZURE_OPENAI_API_BASE")
AZURE_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION")
AZURE_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
AZURE_API_URL = f"{AZURE_API_BASE}openai/deployments/{AZURE_DEPLOYMENT_NAME}/chat/completions?api-version={AZURE_API_VERSION}"

# -----------------------------
# GET: Health check
# -----------------------------
@app.route("/api/health", methods=["GET"])
def health_check():
    return jsonify({
        "status": "healthy",
        "message": "Backend service is running",
        "timestamp": datetime.now(timezone.utc).isoformat()
    }), 200

MAX_CHARS = 10000  # max chars per chunk
JSON_CONTENT_TYPE = "application/json"

def chunk_text(text, max_chars=MAX_CHARS):
    """Split large text into smaller chunks for LLM processing."""
    chunks = []
    start = 0
    while start < len(text):
        end = start + max_chars
        chunks.append(text[start:end])
        start = end
    return chunks
# -----------------------------
# POST: Chat endpoint (Azure OpenAI)
# -----------------------------
MAX_CHARS = 5000  # maximum characters to send to model per section

def truncate_text(text, max_chars=MAX_CHARS):
    return text if len(text) <= max_chars else text[:max_chars] + "\n...[truncated]"

@app.route("/api/chat", methods=["POST"])
def chat_with_proposal():
    try:
        data = request.json
        proposal_id = data.get("proposalId")
        question = data.get("question")
        context = data.get("context", "")

        if not proposal_id or not question:
            return jsonify({"error": "Missing proposalId or question"}), 400

        # Fetch proposal from Firebase
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404

        proposal_data = doc.to_dict()
        rfp_content = truncate_text(proposal_data.get("content", ""))
        files = proposal_data.get("files", [])

        # Merge file contents into truncated context
        file_texts = "\n\n".join(f"{f.get('name')}: {truncate_text(f.get('textContent',''))}" for f in files)
        full_context = f"RFP Content:\n{rfp_content}\n\nAttached Files:\n{file_texts}\n\nAdditional Context:\n{truncate_text(context)}"

        HEADERS = {
            "Content-Type": JSON_CONTENT_TYPE,
            "api-key": AZURE_API_KEY
        }

        payload = {
            "messages": [
                {"role": "system", "content": "You are an assistant helping with RFP analysis."},
                {"role": "user", "content": f"{full_context}\n\nQuestion: {question}"}
            ],
            "max_tokens": 600,
            "temperature": 0.2
        }

        response = requests.post(AZURE_API_URL, headers=HEADERS, json=payload)
        if response.status_code != 200:
            return jsonify({"error": f"OpenAI API error: {response.text}"}), response.status_code

        answer = response.json()["choices"][0]["message"]["content"].strip()
        return jsonify({"answer": answer}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500



# -----------------------------
# POST: Create new proposal with parallel Crew AI analysis
# -----------------------------
@app.route("/api/proposals", methods=["POST"])
def create_proposal():
    data = request.get_json()
    proposal_name = data.get("proposal_name")
    owner_name = data.get("owner_name", "vTechOwner")
    status = data.get("status", "In Progress")
    type_val = data.get("type", "Fed")
    content = data.get("content", "")
    rfp_content = data.get("rfp_content", "")
    files = data.get("files", [])
    last_updated = datetime.now(timezone.utc)

    if not proposal_name:
        return jsonify({"error": "proposal_name is required"}), 400

    try:
        # 1️⃣ Save proposal in Firebase
        doc_ref = db.collection("proposals").add({
            "name": proposal_name,
            "user": owner_name,
            "status": status,
            "type": type_val,
            "content": content,
            "files": files,
            "lastUpdated": last_updated
        })
        proposal_id = doc_ref[1].id

        # 2️⃣ Split content into chunks
        content_chunks = chunk_text(content)

        # 3️⃣ Run analysis in parallel
        def analyze_chunk(chunk):
            return run_analysis(chunk)

        with ThreadPoolExecutor(max_workers=3) as executor:
            analysis_chunks = list(executor.map(analyze_chunk, content_chunks))

        # Merge analysis
        merged_analysis = {
            "keyRequirements": [],
            "projectScope": "",
            "importantDeadlines": [],
            "evaluationCriteria": []
        }
        for chunk_result in analysis_chunks:
            merged_analysis["keyRequirements"].extend(chunk_result.get("keyRequirements", []))
            merged_analysis["importantDeadlines"].extend(chunk_result.get("importantDeadlines", []))
            merged_analysis["evaluationCriteria"].extend(chunk_result.get("evaluationCriteria", []))
            merged_analysis["projectScope"] += "\n" + chunk_result.get("projectScope", "")

        # Deduplicate lists
        merged_analysis["keyRequirements"] = list(set(merged_analysis["keyRequirements"]))
        merged_analysis["importantDeadlines"] = list({d.get("date"): d for d in merged_analysis["importantDeadlines"]}.values())
        merged_analysis["evaluationCriteria"] = list(set(merged_analysis["evaluationCriteria"]))

        # -------------------------------
        # 4️⃣ Run compliance matrix
        # -------------------------------
        compliance_matrix = generate_compliance_matrix(content, rfp_content)

        # 5️⃣ Save analysis + compliance in Firebase
        db.collection("proposal_analysis").document(proposal_id).set({
            "proposalId": proposal_id,
            "analysis": merged_analysis,
            "chunkAnalysis": analysis_chunks,
            "complianceMatrix": compliance_matrix,
            "createdAt": last_updated
        })

        # 6️⃣ Return full response
        response = {
            "id": proposal_id,
            "name": proposal_name,
            "user": owner_name,
            "status": status,
            "type": type_val,
            "content": content,
            "files": files,
            "lastUpdated": last_updated.isoformat(),
            "analysis": merged_analysis,
            "complianceMatrix": compliance_matrix
        }
        return jsonify(response), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/proposals/<proposal_id>/analysis", methods=["GET"])
def get_proposal_analysis(proposal_id):
    try:
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404

        analysis_doc_ref = db.collection("proposal_analysis").document(proposal_id)
        analysis_doc = analysis_doc_ref.get()
        raw_analysis = analysis_doc.to_dict() if analysis_doc.exists else {}

        return jsonify({
            "id": proposal_id,
            "name": doc.to_dict().get("name"),
            "user": doc.to_dict().get("user"),
            "status": doc.to_dict().get("status"),
            "type": doc.to_dict().get("type"),
            "lastUpdated": doc.to_dict().get("lastUpdated").isoformat(),
            "analysis": raw_analysis.get("analysis", {}),
            "complianceMatrix": raw_analysis.get("complianceMatrix", [])
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -----------------------------
# GET: Fetch all proposals
# -----------------------------
@app.route("/api/proposals", methods=["GET"])
def get_proposals():
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    try:
        docs = db.collection("proposals").order_by("lastUpdated", direction=firestore.Query.DESCENDING).stream()
        proposals = []
        for doc in docs:
            d = doc.to_dict()
            proposals.append({
                "id": doc.id,
                "name": d.get("name"),
                "user": d.get("user"),
                "status": d.get("status"),
                "type": d.get("type"),
               "lastUpdated": d.get("lastUpdated").strftime("%m/%d/%y") if d.get("lastUpdated") else None,

                "content": d.get("content", "")
            })
        return jsonify(proposals), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    



from flask import Flask, request, jsonify
from datetime import datetime, timezone
from crewai import Crew
from crew_ai.document_agent import capture
from crew_ai.document_task import capture_task
from crew_ai.document_task import extract_orgname  # adjust import if needed
import re

crew = Crew(
    agent=[capture],
    tasks=[capture_task],
    memory=True,
    cache=True,
    max_rpm=100,
    share_crew=True
)

@app.route("/api/proposals/capture/<proposal_id>", methods=["GET"])
def capture_proposal(proposal_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    try:
        # 1️⃣ Load proposal
        doc = db.collection("proposals").document(proposal_id).get()
        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404
        proposal_data = doc.to_dict()
        content = proposal_data.get("content", "")

        # 2️⃣ Extract organization name
        orgname = extract_orgname(content)

        # 3️⃣ Run Crew agent
        intel_summary = crew.kickoff(inputs={"orgname": orgname})

        # 4️⃣ Normalize CrewOutput to JSON-safe dict
        def normalize(result):
            jd = getattr(result, "json_dict", None)
            if jd:
                return jd
            raw = getattr(result, "raw", None) or str(result)
            try:
                return json.loads(raw)
            except Exception:
                m = re.search(r"\{[\s\S]*\}", raw)
                if m:
                    try:
                        return json.loads(m.group(0))
                    except Exception:
                        pass
            # If all fails, wrap as a fallback
            return {
                "clientProfile": {},
                "incumbentVendors": [],
                "competitors": [],
                "gapAnalysis": [],
                "stakeholders": [],
                "raw": raw
            }

        intel_summary_safe = normalize(intel_summary)

        # 5️⃣ Optional: ensure all top-level keys exist
        structured_response = {
            "clientProfile": intel_summary_safe.get("clientProfile", {}),
            "incumbentVendors": intel_summary_safe.get("incumbentVendors", []),
            "competitors": intel_summary_safe.get("competitors", []),
            "gapAnalysis": intel_summary_safe.get("gapAnalysis", []),
            "stakeholders": intel_summary_safe.get("stakeholders", [])
        }

        # 6️⃣ Save capture in Firestore (optional)
        db.collection("proposal_capture").document(proposal_id).set({
            "proposalId": proposal_id,
            "orgName": orgname,
            "intelligenceSummary": structured_response,
            "updatedAt": datetime.now(timezone.utc).isoformat()
        })

        # 7️⃣ Return structured response
        return jsonify(structured_response), 200

    except Exception as e:
        print(f"❌ Error capturing proposal '{proposal_id}': {e}")
        return jsonify({"error": str(e)}), 500



# file add


@app.route("/api/proposals/<proposal_id>/files", methods=["POST"])
def upload_proposal_files(proposal_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    try:
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404

        proposal_data = doc.to_dict()
        existing_files = proposal_data.get("files", [])
        files = request.files.getlist("files")
        if not files:
            return jsonify({"error": "No files uploaded"}), 400

        # Save uploaded files
        saved_files = []
        for file in files:
            file_bytes = file.read()
            file_size = round(len(file_bytes) / 1024, 2)
            file.seek(0)
            file_text = extract_file_content(file)
            file_id = str(uuid.uuid4())
            saved_files.append({
                "id": file_id,
                "name": file.filename,
                "type": file.filename.split(".")[-1].lower(),
                "size": f"{file_size} KB",
                "textContent": file_text
            })

        updated_files = existing_files + saved_files
        doc_ref.update({"files": updated_files, "lastUpdated": datetime.now(timezone.utc)})

        # Combine content + all file text
        combined_text = proposal_data.get("content", "")
        combined_text += "\n\n".join(f.get("textContent", "") for f in updated_files)

        # Run analysis synchronously
        MAX_CHARS_PER_CHUNK = 12000
        chunks = chunk_text(combined_text, max_chars=MAX_CHARS_PER_CHUNK)
        chunk_results = []

        for idx, text_chunk in enumerate(chunks):
            prompt = (
                f"Chunk {idx+1} of {len(chunks)}:\n{text_chunk}\n\n"
                "You MUST return valid JSON ONLY with this structure:\n"
                "{"
                "\"keyRequirements\": [], "
                "\"projectScope\": \"\", "
                "\"importantDeadlines\": [], "
                "\"evaluationCriteria\": []"
                "}\n"
            )
            res = run_analysis(prompt)
            chunk_results.append(res)

        # Merge results
        merged_analysis = {
            "keyRequirements": [],
            "projectScope": "",
            "importantDeadlines": [],
            "evaluationCriteria": []
        }
        for res in chunk_results:
            merged_analysis["keyRequirements"].extend(res.get("keyRequirements", []))
            merged_analysis["importantDeadlines"].extend(res.get("importantDeadlines", []))
            merged_analysis["evaluationCriteria"].extend(res.get("evaluationCriteria", []))
            merged_analysis["projectScope"] += "\n" + res.get("projectScope", "")

        # Deduplicate
        merged_analysis["keyRequirements"] = list(set(merged_analysis["keyRequirements"]))
        merged_analysis["importantDeadlines"] = list({d.get("date"): d for d in merged_analysis["importantDeadlines"]}.values())
        merged_analysis["evaluationCriteria"] = list(set(merged_analysis["evaluationCriteria"]))

        # Save analysis
        db.collection("proposal_analysis").document(proposal_id).set({
            "proposalId": proposal_id,
            "analysis": merged_analysis,
            "chunkAnalysis": chunk_results,
            "updatedAt": datetime.now(timezone.utc)
        }, merge=True)

        return jsonify({
            "newFiles": saved_files,
            "analysis": merged_analysis,
            "message": "Files uploaded and analyzed successfully"
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

        
# Delete file



@app.route("/api/proposals/<proposal_id>/files/<file_id>", methods=["DELETE"])
def delete_proposal_file(proposal_id, file_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    try:
        file_id = unquote(file_id)
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404

        proposal_data = doc.to_dict()
        files = proposal_data.get("files", [])
        updated_files = [f for f in files if f.get("id") != file_id]

        if len(files) == len(updated_files):
            return jsonify({"error": "File not found"}), 404

        doc_ref.update({"files": updated_files, "lastUpdated": datetime.now(timezone.utc)})

        # Combine content + remaining files
        combined_text = proposal_data.get("content", "")
        for f in updated_files:
            combined_text += "\n\n" + f.get("textContent", "")

        # Run analysis synchronously (same as above)
        MAX_CHARS_PER_CHUNK = 12000
        chunks = chunk_text(combined_text, max_chars=MAX_CHARS_PER_CHUNK)
        chunk_results = []

        for idx, text_chunk in enumerate(chunks):
            prompt = (
                f"Chunk {idx+1} of {len(chunks)}:\n{text_chunk}\n\n"
                "You MUST return valid JSON ONLY with this structure:\n"
                "{"
                "\"keyRequirements\": [], "
                "\"projectScope\": \"\", "
                "\"importantDeadlines\": [], "
                "\"evaluationCriteria\": []"
                "}\n"
            )
            res = run_analysis(prompt)
            chunk_results.append(res)

        # Merge results
        merged_analysis = {
            "keyRequirements": [],
            "projectScope": "",
            "importantDeadlines": [],
            "evaluationCriteria": []
        }
        for res in chunk_results:
            merged_analysis["keyRequirements"].extend(res.get("keyRequirements", []))
            merged_analysis["importantDeadlines"].extend(res.get("importantDeadlines", []))
            merged_analysis["evaluationCriteria"].extend(res.get("evaluationCriteria", []))
            merged_analysis["projectScope"] += "\n" + res.get("projectScope", "")

        # Deduplicate
        merged_analysis["keyRequirements"] = list(set(merged_analysis["keyRequirements"]))
        merged_analysis["importantDeadlines"] = list({d.get("date"): d for d in merged_analysis["importantDeadlines"]}.values())
        merged_analysis["evaluationCriteria"] = list(set(merged_analysis["evaluationCriteria"]))

        # Save analysis
        db.collection("proposal_analysis").document(proposal_id).set({
            "proposalId": proposal_id,
            "analysis": merged_analysis,
            "chunkAnalysis": chunk_results,
            "updatedAt": datetime.now(timezone.utc)
        }, merge=True)

        return jsonify({
            "message": f"File {file_id} deleted and analysis updated successfully",
            "files": updated_files,
            "analysis": merged_analysis
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    try:
        file_id = unquote(file_id)

        # 1️⃣ Fetch proposal
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404

        proposal_data = doc.to_dict()
        files = proposal_data.get("files", [])
        updated_files = [f for f in files if f.get("id") != file_id]

        if len(files) == len(updated_files):
            return jsonify({"error": "File not found"}), 404

        # 2️⃣ Update Firestore immediately
        doc_ref.update({"files": updated_files, "lastUpdated": datetime.now(timezone.utc)})

        # 3️⃣ Combine content + remaining files
        combined_text = proposal_data.get("content", "")
        for f in updated_files:
            combined_text += "\n\n" + f.get("textContent", "")

        # 4️⃣ Background analysis function
        def background_analysis(proposal_id, combined_text):
            MAX_CHARS_PER_CHUNK = 12000
            content_chunks = chunk_text(combined_text, max_chars=MAX_CHARS_PER_CHUNK)

            def analyze_chunk(chunk_info):
                idx, chunk_text = chunk_info
                prompt = (
                    f"Chunk {idx+1} of {len(content_chunks)}:\n{chunk_text}\n\n"
                    "You MUST return valid JSON ONLY with this structure:\n"
                    "{"
                    "\"keyRequirements\": [], "
                    "\"projectScope\": \"\", "
                    "\"importantDeadlines\": [], "
                    "\"evaluationCriteria\": []"
                    "}\n"
                )
                return run_analysis(prompt)

            with ThreadPoolExecutor(max_workers=5) as executor:
                chunk_results = list(executor.map(analyze_chunk, enumerate(content_chunks)))

            # Merge results
            merged_analysis = {
                "keyRequirements": [],
                "projectScope": "",
                "importantDeadlines": [],
                "evaluationCriteria": []
            }
            for res in chunk_results:
                merged_analysis["keyRequirements"].extend(res.get("keyRequirements", []))
                merged_analysis["importantDeadlines"].extend(res.get("importantDeadlines", []))
                merged_analysis["evaluationCriteria"].extend(res.get("evaluationCriteria", []))
                merged_analysis["projectScope"] += "\n" + res.get("projectScope", "")

            # Deduplicate
            merged_analysis["keyRequirements"] = list(set(merged_analysis["keyRequirements"]))
            merged_analysis["importantDeadlines"] = list({d.get("date"): d for d in merged_analysis["importantDeadlines"]}.values())
            merged_analysis["evaluationCriteria"] = list(set(merged_analysis["evaluationCriteria"]))

            # Save analysis
            db.collection("proposal_analysis").document(proposal_id).set({
                "proposalId": proposal_id,
                "analysis": merged_analysis,
                "chunkAnalysis": chunk_results,
                "updatedAt": datetime.now(timezone.utc)
            }, merge=True)

        # 5️⃣ Run background analysis
        Thread(target=background_analysis, args=(proposal_id, combined_text)).start()

        # 6️⃣ Return response immediately
        return jsonify({
            "message": f"File {file_id} deleted successfully, analysis running in background",
            "files": updated_files
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500



# ✅ Get proposal details only
@app.route("/api/proposals/<proposal_id>", methods=["GET"])
def get_proposal_details(proposal_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    try:
        # 1️⃣ Fetch the main proposal
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404

        proposal_data = doc.to_dict()

        # 2️⃣ Format lastUpdated
        last_updated = proposal_data.get("lastUpdated")
        if last_updated:
            last_updated = (
                last_updated.isoformat()
                if hasattr(last_updated, "isoformat")
                else str(last_updated)
            )

        # 3️⃣ Return only details
        return jsonify({
            "id": doc.id,
            "name": proposal_data.get("name"),
            "user": proposal_data.get("user"),
            "status": proposal_data.get("status"),
            "type": proposal_data.get("type"),
            "lastUpdated": last_updated,
            "files": proposal_data.get("files", []),
        }), 200

    except Exception as e:
        print(f"❌ Error fetching proposal '{proposal_id}': {e}")
        return jsonify({"error": str(e)}), 500




# -----------------------------
# POST: Generate Compliance Matrix by Proposal ID
# -----------------------------
@app.route("/api/proposals/<proposal_id>/compliance", methods=["POST"])
def create_proposal_compliance(proposal_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    try:
        # 1️⃣ Fetch proposal content
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404

        proposal_data = doc.to_dict()
        proposal_content = proposal_data.get("content", "")

        # 2️⃣ Use rfp_content from request or fallback
        data = request.get_json(silent=True) or {}
        rfp_content = data.get("rfp_content") or proposal_content

        # 3️⃣ Clean text function
        def clean_text(text):
            text = re.sub(r'<[^>]+>', '', text)  # remove HTML
            text = re.sub(r'\s+', ' ', text)     # remove extra spaces/newlines
            return text.strip()

        proposal_content = clean_text(proposal_content)
        rfp_content = clean_text(rfp_content)

        # 4️⃣ Split content into smaller chunks
        MAX_CHARS_PER_CHUNK = 3000
        def chunk_text(text, max_chars=MAX_CHARS_PER_CHUNK):
            chunks = []
            start = 0
            while start < len(text):
                end = start + max_chars
                chunks.append(text[start:end])
                start = end
            return chunks

        proposal_chunks = chunk_text(proposal_content)
        rfp_chunks = chunk_text(rfp_content)

        # 5️⃣ Safe compliance generator with retry
        def safe_generate_compliance(p_chunk, r_chunk):
            for _ in range(2):  # retry once if fails
                result = generate_compliance_matrix(p_chunk, r_chunk)
                if isinstance(result, list) and result:
                    return result
            return []  # fallback empty

        # 6️⃣ Run all chunks in parallel
        merged_matrix = []
        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = [executor.submit(safe_generate_compliance, p, r) 
                       for p, r in zip(proposal_chunks, rfp_chunks)]
            for f in futures:
                merged_matrix.extend(f.result())

        # 7️⃣ Limit rows to top 6
        merged_matrix = merged_matrix[:6]

        # 8️⃣ Save to Firestore
        db.collection("proposal_compliance").document(proposal_id).set({
            "proposalId": proposal_id,
            "complianceMatrix": merged_matrix,
            "createdAt": datetime.now(timezone.utc)
        })

        return jsonify({
            "proposalId": proposal_id,
            "complianceMatrix": merged_matrix
        }), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -----------------------------
# GET: Fetch Compliance Matrix
# -----------------------------



@app.route("/api/proposals/<proposal_id>/compliance", methods=["POST"])
def create_compliance_matrix(proposal_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    try:
        # 1️⃣ Fetch proposal content
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404

        proposal_content = doc.to_dict().get("content", "")

        # 2️⃣ Use rfp_content from request or fallback
        data = request.get_json(silent=True) or {}
        rfp_content = data.get("rfp_content") or proposal_content

        # 3️⃣ Split content into smaller chunks
        MAX_CHARS_PER_CHUNK = 6000  # safe chunk size

        def chunk_text(text, max_chars=MAX_CHARS_PER_CHUNK):
            chunks = []
            start = 0
            while start < len(text):
                end = start + max_chars
                chunks.append(text[start:end])
                start = end
            return chunks

        proposal_chunks = chunk_text(proposal_content)
        rfp_chunks = chunk_text(rfp_content)

        # 4️⃣ Safe wrapper for compliance matrix generation
        def safe_generate_compliance_matrix(p_chunk, r_chunk):
            try:
                result = generate_compliance_matrix(p_chunk, r_chunk)
                if isinstance(result, str):
                    return json.loads(result)
                elif isinstance(result, dict):
                    return result
                elif isinstance(result, list):
                    return result
                else:
                    return {"error": "Unknown result type"}
            except Exception as e:
                return {"error": str(e)}

        # 5️⃣ Run all chunks in parallel
        merged_matrix = []

        with ThreadPoolExecutor(max_workers=3) as executor:
            results = list(
                executor.map(
                    lambda x: safe_generate_compliance_matrix(*x),
                    zip_longest(proposal_chunks, rfp_chunks, fillvalue="")
                )
            )

        # 6️⃣ Merge results
        for partial_matrix in results:
            if isinstance(partial_matrix, dict) and "error" in partial_matrix:
                print(f"⚠️ Partial matrix error: {partial_matrix['error']}")
            elif isinstance(partial_matrix, list):
                merged_matrix.extend(partial_matrix)

        # Optional: limit to first 6 rows
        merged_matrix = merged_matrix[:6]

        # 7️⃣ Save to Firestore
        db.collection("proposal_compliance").document(proposal_id).set({
            "proposalId": proposal_id,
            "complianceMatrix": merged_matrix,
            "createdAt": datetime.now(timezone.utc)
        })

        return jsonify({
            "proposalId": proposal_id,
            "complianceMatrix": merged_matrix
        }), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500





# -----------------------------
# PUT: Update proposal
# -----------------------------
@app.route("/api/proposals/<proposal_id>", methods=["PUT"])
def update_proposal(proposal_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    data = request.get_json()
    try:
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()

        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404

        update_data = {
            "name": data.get("proposal_name", doc.to_dict().get("name")),
            "user": data.get("owner_name", doc.to_dict().get("user")),
            "status": data.get("status", doc.to_dict().get("status")),
            "type": data.get("type", doc.to_dict().get("type")),
            "content": data.get("content", doc.to_dict().get("content")),
            "lastUpdated": datetime.now(timezone.utc)
        }
        doc_ref.update(update_data)

        return jsonify({"message": f"Proposal {proposal_id} updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -----------------------------
# DELETE: Delete proposal
# -----------------------------
@app.route("/api/proposals/<proposal_id>", methods=["DELETE"])
def delete_proposal(proposal_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    try:
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()

        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404

        doc_ref.delete()
        return jsonify({"message": f"Proposal {proposal_id} deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# -----------------------------
# Helper functions
# -----------------------------
def save_knowledge_item(content: str, source: str, type_val: str, category: str) -> str:
    """Save a knowledge item to Firebase and return its ID."""
    doc_ref = db.collection("knowledge").add({
        "content": content.strip(),
        "source": source,
        "type": type_val,
        "category": category,
        "createdAt": datetime.now(timezone.utc)
    })
    return doc_ref[1].id

def extract_file_content(file) -> str:
    """Extract text content from uploaded file."""
    filename = file.filename.lower()
    if filename.endswith(".txt"):
        return file.read().decode("utf-8", errors="ignore")
    elif filename.endswith(".pdf"):
        reader = PyPDF2.PdfReader(file)
        return "\n".join([p.extract_text() for p in reader.pages if p.extract_text()])
    elif filename.endswith(".docx"):
        doc = docx.Document(file)
        return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
    return ""

def fetch_url_text(url: str) -> str:
    """Fetch and parse text from a URL."""
    try:
        resp = requests.get(url)
        if resp.status_code != 200:
            return ""
        soup = BeautifulSoup(resp.text, "html.parser")
        return soup.get_text(separator="\n").strip()
    except Exception:
        return ""

# -----------------------------
# Constants
# -----------------------------
MANUAL_INPUT_SOURCE = "manual input"

# -----------------------------
# POST: Add knowledge (manual text, file upload, or URL) also add file in storage section by folder str
# -----------------------------
@app.route("/api/knowledge", methods=["POST"])
def add_knowledge():
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    added_items = []

    def add_text(content: str, source: str, type_val: str, category: str):
        if content.strip():
            item_id = save_knowledge_item(content, source, type_val, category)
            added_items.append({"id": item_id, "source": source})

    try:
        # 1️⃣ JSON body (manual input)
        if request.is_json:
            data = request.get_json()
            add_text(
                content=data.get("content", ""),
                source=MANUAL_INPUT_SOURCE,
                type_val=data.get("type", "manual"),
                category=data.get("category", "General")
            )

        # 2️⃣ Form data (manual text, files, URL)
        elif request.form or request.files:
            category = request.form.get("category", "General")

            # Manual text in form-data
            add_text(
                content=request.form.get("content", ""),
                source=MANUAL_INPUT_SOURCE,
                type_val="text",
                category=category
            )

            # Files
            for file in request.files.getlist("files"):
                add_text(
                    content=extract_file_content(file),
                    source=file.filename,
                    type_val="file",
                    category=category
                )

            # URL
            url = request.form.get("url", "").strip()
            if url:
                add_text(
                    content=fetch_url_text(url),
                    source=url,
                    type_val="url",
                    category=category
                )

        else:
            return jsonify({"error": "No content provided"}), 400

        return jsonify({"message": f"{len(added_items)} items uploaded", "added": added_items}), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -----------------------------
# GET: Fetch all knowledge items
# -----------------------------
@app.route("/api/knowledge", methods=["GET"])
def get_knowledge():
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500
    try:
        docs = db.collection("knowledge").order_by("createdAt", direction=firestore.Query.DESCENDING).stream()
        items = []
        for doc in docs:
            d = doc.to_dict()
            items.append({
                "id": doc.id,
                "content": d.get("content"),
                "source": d.get("source"),
                "type": d.get("type"),
                "category": d.get("category"),
                "createdAt": d.get("createdAt").isoformat() if d.get("createdAt") else None
            })
        return jsonify(items), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -----------------------------
# PUT: Update knowledge item
# -----------------------------
@app.route("/api/knowledge/<item_id>", methods=["PUT"])
def update_knowledge(item_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500
    try:
        data = request.get_json()
        doc_ref = db.collection("knowledge").document(item_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Knowledge item not found"}), 404

        update_data = {
            "content": data.get("content", doc.to_dict().get("content")),
            "source": data.get("source", doc.to_dict().get("source")),
            "type": data.get("type", doc.to_dict().get("type")),
            "category": data.get("category", doc.to_dict().get("category")),
            "updatedAt": datetime.now(timezone.utc)
        }
        doc_ref.update(update_data)
        return jsonify({"message": f"Knowledge item {item_id} updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -----------------------------
# DELETE: Remove knowledge item
# -----------------------------
@app.route("/api/knowledge/<item_id>", methods=["DELETE"])
def delete_knowledge(item_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500
    try:
        doc_ref = db.collection("knowledge").document(item_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Knowledge item not found"}), 404
        doc_ref.delete()
        return jsonify({"message": f"Knowledge item {item_id} deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -----------------------------
# POST: Bulk delete knowledge
# -----------------------------
@app.route("/api/knowledge/bulk-delete", methods=["POST"])
def bulk_delete_knowledge():
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500
    try:
        data = request.get_json()
        ids = data.get("ids", [])
        deleted = []

        for item_id in ids:
            doc_ref = db.collection("knowledge").document(item_id)
            if doc_ref.get().exists:
                doc_ref.delete()
                deleted.append(item_id)

        return jsonify({"message": f"{len(deleted)} items deleted", "deleted": deleted}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ---------------- Summarize Knowledge ----------------
class AzureSummarizationAPIError(Exception):
    """Raised when the Azure summarization API returns a non-200 response."""
    def __init__(self, status_code: int, message: str):
        super().__init__(f"Azure summarization API error ({status_code}): {message}")
        self.status_code = status_code
        self.message = message

def summarize_knowledge(knowledge_content: str) -> str:
    """
    Compresses long knowledge base content into a short summary
    so it fits within the Azure model context limit.
    """
    if not knowledge_content.strip():
        return ""

    headers = {"Content-Type": JSON_CONTENT_TYPE, "api-key": AZURE_API_KEY}
    summary_prompt = f"Summarize the following knowledge base content into concise key requirements:\n\n{knowledge_content[:8000]}"

    payload = {
        "messages": [
            {"role": "system", "content": "You are a summarizer for large knowledge documents."},
            {"role": "user", "content": summary_prompt}
        ],
        "max_tokens": 800,
        "temperature": 0.0
    }

    response = requests.post(AZURE_API_URL, headers=headers, json=payload)
    if response.status_code != 200:
        raise AzureSummarizationAPIError(response.status_code, response.text)

    return response.json()["choices"][0]["message"]["content"].strip()



# ---------------- API Route ----------------
class AzureAPIError(Exception):
    """Raised when the Azure API returns a non-200 response."""
    def __init__(self, status_code: int, message: str):
        super().__init__(f"Azure API error ({status_code}): {message}")
        self.status_code = status_code
        self.message = message

@app.route("/api/proposals/<proposal_id>/gap-analysis", methods=["POST"])
def gap_analysis(proposal_id):
    try:
        data = request.json
        knowledge_sources = data.get("knowledgeSources", [])
        if not proposal_id:
            return jsonify({"error": "Missing proposal_id"}), 400
        if not knowledge_sources or not isinstance(knowledge_sources, list):
            return jsonify({"error": "Missing or invalid knowledgeSources"}), 400

        # ---- Fetch Proposal ----
        doc_ref = db.collection("proposals").document(proposal_id)
        doc = doc_ref.get()
        if not doc.exists:
            return jsonify({"error": "Proposal not found"}), 404
        proposal_data = doc.to_dict()
        proposal_content = proposal_data.get("content", "")

        # ---- Fetch Knowledge Sources ----
        knowledge_content = ""
        for source in knowledge_sources:
            knowledge_docs = db.collection("knowledge").where("source", "==", source).stream()
            for d in knowledge_docs:
                knowledge_content += d.to_dict().get("content", "") + "\n\n"

        if not knowledge_content.strip():
            return jsonify({"error": f"No knowledge items found for selected sources {knowledge_sources}"}), 404

        # ---- Summarize Knowledge ----
        summarized_knowledge = summarize_knowledge(knowledge_content)

        # ---- Build Prompt for GPT ----
        prompt = f"""
You are an assistant that extracts structured information from proposals.
Use the proposal content and summarized knowledge base to generate JSON output.

Proposal Content:
{proposal_content[:6000]}  # trim to avoid context overflow

Knowledge Summary:
{summarized_knowledge}

Tasks:
1. Extract metadata:
   - rfpNumber
   - projectTitle
   - facilityClearance (Yes/No)
   - securityClearance (Yes/No)
   - Other Gaps or Concerns (list)
   - businessTypes (list)
2. Build a scorecard comparing proposal to knowledge base:
   - functionalArea
   - task
   - expCapabilityScore (1–5)
   - writingCapabilityScore (1–5)
   - customerExperienceScore (1–5)
   - comments

Return JSON ONLY with two keys:
- "metadata": { ... }
- "scorecard": [ ... ]
"""

        headers = {"Content-Type": "application/json", "api-key": AZURE_API_KEY}
        payload = {
            "messages": [
                {"role": "system", "content": "You are a strict JSON generator for RFP gap analysis."},
                {"role": "user", "content": prompt}
            ],
            "max_tokens": 1500,
            "temperature": 0.2
        }

        response = requests.post(AZURE_API_URL, headers=headers, json=payload)
        if response.status_code != 200:
             raise AzureAPIError(response.status_code, response.text)

        analysis_text = response.json()["choices"][0]["message"]["content"].strip()
        analysis_data = json.loads(analysis_text)

        return jsonify({
            "proposalId": proposal_id,
            "knowledgeSources": knowledge_sources,
            "analysis": analysis_data
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500



@app.route("/api/proposals/<proposal_id>/gap-analysis/save", methods=["POST"])
def save_gap_analysis(proposal_id):
    if db is None:
        return jsonify({"error": "Firebase not initialized"}), 500

    try:
        data = request.get_json()
        knowledge_source = data.get("knowledgeSource")
        analysis = data.get("analysis")

        if not knowledge_source or not analysis:
            return jsonify({"error": "Missing knowledgeSource or analysis"}), 400

        doc_ref = db.collection("proposal_analysis").document(proposal_id)

        # overwrite only this knowledge source
        doc_ref.set({
            "analysis": {
                "gapAnalysis": {
                    knowledge_source: analysis
                }
            }
        }, merge=True)  # <-- keep other keys (requirements, scope, etc.)

        return jsonify({"success": True}), 200

    except Exception as e:
        print(f"❌ Error saving gap analysis: {e}")
        return jsonify({"error": str(e)}), 500



# -----------------------------
# Run server
# -----------------------------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002, debug=True)
