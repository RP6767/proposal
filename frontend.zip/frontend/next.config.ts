import type {NextConfig} from 'next';

const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'placehold.co',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'picsum.photos',
        port: '',
        pathname: '/**',
      },
    ],
  },
  webpack: (config, { isServer }) => {
    // This is to make `pdfjs-dist` work with Next.js
    // See https://github.com/mozilla/pdf.js/issues/13373
    if (!isServer) {
        config.resolve.alias = {
            ...config.resolve.alias,
            'pdfjs-dist/build/pdf.worker.js': 'pdfjs-dist/build/pdf.worker.min.mjs',
        };
    }
    return config;
  },
};

export default nextConfig;
