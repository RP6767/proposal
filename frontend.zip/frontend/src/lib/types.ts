import type { AnalyzeRFPContentOutput as AnalyzeOutput } from '@/ai/flows/analyze-rfp-content';
import type { AnswerRfpQuestionsOutput } from '@/ai/flows/answer-rfp-questions';
import type { DraftProposalSectionsOutput as DraftOutput } from '@/ai/flows/draft-proposal-sections';
import type { GenerateClientProfileOutput as CaptureOutput } from '@/ai/flows/generate-client-profile';
import type { GenerateProposalOutlineOutput } from '@/ai/flows/generate-proposal-outline';
import type { GenerateComplianceMatrixOutput as ComplianceOutput, ComplianceMatrixRow as ComplianceRow } from '@/ai/flows/generate-compliance-matrix';


export type DraftProposalSectionsOutput = DraftOutput;
export type AnalyzeRFPContentOutput = AnalyzeOutput;
export type GenerateClientProfileOutput = CaptureOutput;
export type GenerateComplianceMatrixOutput = ComplianceOutput;
export type ComplianceMatrixRow = ComplianceRow;

export type {
  AnswerRfpQuestionsOutput,
  GenerateProposalOutlineOutput,
};

export type KnowledgeCategory = 'Fed' | 'SLED' | 'General';
export type ProposalType = 'Fed' | 'SLED';

export type KnowledgeItem = {
    content: string;
    source: string;
    type: 'manual' | 'file' | 'url';
    category: KnowledgeCategory;
};

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export type OutlineSection = {
  id: number;
  title: string;
  description: string;
};

export type ProposalSection = {
  content: string;
  source: 'AI-generated' | 'Knowledge Base';
  knowledgeBaseExcerpts: string[];
}

export type AnalysisSection = {
  content: string;
  source: 'AI-generated' | 'Knowledge Base';
}

export type AttachedDocument = {
    id: string;
    name: string;
    type: 'pdf' | 'docx' | 'txt' | 'other';
    size: string;
}
