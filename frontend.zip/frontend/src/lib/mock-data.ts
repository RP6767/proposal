import type { KnowledgeItem } from './types';

export const MOCK_KB_CONTENT: KnowledgeItem[] = [
    { content: "vTech is a CMMI Level 3 certified company.", source: "manual input", type: 'manual', category: 'Fed'},
    { content: "We hold a GSA Schedule 70 contract.", source: "manual input", type: 'manual', category: 'Fed'},
    { content: "Our team has extensive experience with state-level procurement processes.", source: "manual input", type: 'manual', category: 'SLED'},
    { content: "vTech is a leading provider of innovative software solutions, specializing in cloud-native application development, enterprise-grade AI integration, and scalable data platforms. With over 15 years of experience, we have successfully delivered more than 200 projects for Fortune 500 companies.", source: "manual input", type: 'manual', category: 'General'},
    { content: "Our core competencies include: React, Next.js, TypeScript, Python, and Google Cloud Platform (GCP). We are a certified Google Cloud Partner.", source: "manual input", type: 'manual', category: 'General' },
    { content: "Our project management methodology is based on Agile principles, ensuring iterative development, transparent communication, and on-time delivery. We use Jira for tracking and have a 98% client satisfaction rate.", source: "manual input", type: 'manual', category: 'General' }
];

    