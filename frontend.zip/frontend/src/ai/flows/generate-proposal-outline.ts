'use server';

/**
 * @fileOverview This flow generates a tailored proposal outline based on RFP content and the company's knowledge base.
 *
 * - generateProposalOutline - A function that generates the outline.
 * - GenerateProposalOutlineInput - The input type for the generateProposalOutline function.
 * - GenerateProposalOutlineOutput - The return type for the generateProposalOutline function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateProposalOutlineInputSchema = z.object({
  rfpContent: z.string().describe('The content of the RFP document.'),
  knowledgeBaseContent: z.string().describe('Boilerplate content and company information from the knowledge base.'),
});
export type GenerateProposalOutlineInput = z.infer<typeof GenerateProposalOutlineInputSchema>;


const OutlineSectionSchema = z.object({
    id: z.number().describe('A unique ID for the section.'),
    title: z.string().describe('The title of the proposal section.'),
    description: z.string().describe('A brief description of what this section should cover, tailored to the RFP and knowledge base.'),
});

const GenerateProposalOutlineOutputSchema = z.object({
  outline: z.array(OutlineSectionSchema).describe('A structured proposal outline with sections tailored to the RFP.'),
});
export type GenerateProposalOutlineOutput = z.infer<typeof GenerateProposalOutlineOutputSchema>;

export async function generateProposalOutline(input: GenerateProposalOutlineInput): Promise<GenerateProposalOutlineOutput> {
  return generateProposalOutlineFlow(input);
}

const generateProposalOutlinePrompt = ai.definePrompt({
  name: 'generateProposalOutlinePrompt',
  input: {schema: GenerateProposalOutlineInputSchema},
  output: {schema: GenerateProposalOutlineOutputSchema},
  prompt: `You are an AI assistant that creates tailored proposal outlines. Based on the provided RFP content and the company's knowledge base, generate a structured proposal outline. 

The standard sections are Executive Summary, Technical Approach, Management Approach, Past Performance, and Appendices. 

Analyze the RFP and knowledge base to determine if any additional sections are needed or if the descriptions of the standard sections should be customized to better address the client's needs.

RFP Content: {{{rfpContent}}}

Knowledge Base: {{{knowledgeBaseContent}}}

Generate the proposal outline.`,
});

const generateProposalOutlineFlow = ai.defineFlow(
  {
    name: 'generateProposalOutlineFlow',
    inputSchema: GenerateProposalOutlineInputSchema,
    outputSchema: GenerateProposalOutlineOutputSchema,
  },
  async input => {
    const {output} = await generateProposalOutlinePrompt(input);
    return output!;
  }
);
