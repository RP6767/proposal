'use server';
/**
 * @fileOverview Analyzes RFP content to extract key requirements, scope, and deadlines.
 *
 * - analyzeRFPContent - A function that analyzes RFP content.
 * - AnalyzeRFPContentInput - The input type for the analyzeRFPContent function.
 * - AnalyzeRFPContentOutput - The return type for the analyzeRFPContent function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeRFPContentInputSchema = z.object({
  rfpContent: z.string().describe('The content of the RFP document.'),
  knowledgeBaseContent: z.string().optional().describe('Relevant content from the knowledge base to incorporate into the analysis.'),
});
export type AnalyzeRFPContentInput = z.infer<typeof AnalyzeRFPContentInputSchema>;

const SectionSchema = z.object({
    content: z.string().describe("The analysis for the section. MUST be a bulleted list using Markdown (e.g., '- Item 1\\n- Item 2'). Each point MUST be on a new line."),
    source: z.enum(['AI-generated', 'Knowledge Base']).describe('The primary source of the content for this section.'),
});


const AnalyzeRFPContentOutputSchema = z.object({
  requirements: SectionSchema,
  scope: SectionSchema,
  deadlines: SectionSchema,
  evaluationCriteria: SectionSchema,
  gapAnalysis: SectionSchema,
});
export type AnalyzeRFPContentOutput = z.infer<typeof AnalyzeRFPContentOutputSchema>;

export async function analyzeRFPContent(input: AnalyzeRFPContentInput): Promise<AnalyzeRFPContentOutput> {
  return analyzeRFPContentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzeRFPContentPrompt',
  input: {schema: AnalyzeRFPContentInputSchema},
  output: {schema: AnalyzeRFPContentOutputSchema},
  prompt: `You are an AI assistant tasked with analyzing RFP documents.

  Your goal is to extract the key requirements, project scope, important deadlines, evaluation criteria, and perform a gap analysis.

  For every field in your output, you MUST format the response as a bulleted list using Markdown.
  - Start each point with a hyphen.
  - Each point MUST be on a new line. Do not combine points into a single paragraph.

  When knowledge base content is provided, you should use it to inform your analysis, especially for the Gap Analysis section.
  For each section, determine the primary source of the information. If the section is mostly standard analysis of the RFP, set the 'source' to 'AI-generated'. If the section's insights are directly derived from the provided knowledge base (e.g., comparing RFP requirements to company capabilities for the gap analysis), set the 'source' to 'Knowledge Base'.

  RFP Content: {{{rfpContent}}}
  
  {{#if knowledgeBaseContent}}
  Knowledge Base:
  {{{knowledgeBaseContent}}}
  {{/if}}
  `,
});

const analyzeRFPContentFlow = ai.defineFlow(
  {
    name: 'analyzeRFPContentFlow',
    inputSchema: AnalyzeRFPContentInputSchema,
    outputSchema: AnalyzeRFPContentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
