// src/ai/flows/answer-rfp-questions.ts
'use server';

/**
 * @fileOverview This file defines a Genkit flow for answering questions about RFP content.
 *
 * - answerRfpQuestions - A function that answers user questions based on RFP content.
 * - AnswerRfpQuestionsInput - The input type for the answerRfpQuestions function.
 * - AnswerRfpQuestionsOutput - The return type for the answerRfpQuestions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnswerRfpQuestionsInputSchema = z.object({
  rfpContent: z.string().describe('The content of the RFP document.'),
  question: z.string().describe('The question to be answered based on the RFP content.'),
});
export type AnswerRfpQuestionsInput = z.infer<typeof AnswerRfpQuestionsInputSchema>;

const AnswerRfpQuestionsOutputSchema = z.object({
  answer: z.string().describe('The AI-driven answer to the question based on the RFP content.'),
});
export type AnswerRfpQuestionsOutput = z.infer<typeof AnswerRfpQuestionsOutputSchema>;

export async function answerRfpQuestions(input: AnswerRfpQuestionsInput): Promise<AnswerRfpQuestionsOutput> {
  return answerRfpQuestionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'answerRfpQuestionsPrompt',
  input: {schema: AnswerRfpQuestionsInputSchema},
  output: {schema: AnswerRfpQuestionsOutputSchema},
  prompt: `You are an AI assistant specialized in answering questions about Request for Proposals (RFPs).
  Based on the content of the RFP provided, answer the following question to the best of your ability.

RFP Content: {{{rfpContent}}}

Question: {{{question}}}

Answer: `,
});

const answerRfpQuestionsFlow = ai.defineFlow(
  {
    name: 'answerRfpQuestionsFlow',
    inputSchema: AnswerRfpQuestionsInputSchema,
    outputSchema: AnswerRfpQuestionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
