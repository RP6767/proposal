'use server';

/**
 * @fileOverview AI flow to draft proposal sections based on the approved outline and knowledge base.
 *
 * - draftProposalSections - Function to generate proposal sections.
 * - DraftProposalSectionsInput - Input type for the function.
 * - DraftProposalSectionsOutput - Output type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const DraftProposalSectionsInputSchema = z.object({
  proposalOutline: z
    .string()
    .describe('The approved proposal outline to guide section drafting.'),
  rfpContent: z
    .string()
    .describe('The RFP content to provide context for section drafting.'),
  knowledgeBaseContent: z
    .string()
    .describe('Relevant content from the knowledge base to incorporate into the sections.'),
});

export type DraftProposalSectionsInput = z.infer<
  typeof DraftProposalSectionsInputSchema
>;

const SectionSchema = z.object({
    content: z.string().describe('The drafted content for the section.'),
    source: z.enum(['AI-generated', 'Knowledge Base']).describe('The primary source of the content for this section.'),
    knowledgeBaseExcerpts: z.array(z.string()).describe('Specific excerpts from the knowledge base that were used in this section.')
});


const DraftProposalSectionsOutputSchema = z.object({
  executiveSummary: SectionSchema,
  technicalApproach: SectionSchema,
  managementApproach: SectionSchema,
  pastPerformance: SectionSchema,
  appendices: SectionSchema,
});

export type DraftProposalSectionsOutput = z.infer<
  typeof DraftProposalSectionsOutputSchema
>;

export async function draftProposalSections(
  input: DraftProposalSectionsInput
): Promise<DraftProposalSectionsOutput> {
  return draftProposalSectionsFlow(input);
}

const draftProposalSectionsPrompt = ai.definePrompt({
  name: 'draftProposalSectionsPrompt',
  input: {schema: DraftProposalSectionsInputSchema},
  output: {schema: DraftProposalSectionsOutputSchema},
  prompt: `You are an AI proposal writer. Your task is to draft the sections of a proposal based on a given outline, RFP content, and a knowledge base of company information.

For each section, you must:
1.  Write the full content for the section, making sure it addresses the requirements in the RFP and incorporates relevant information from the knowledge base.
2.  Determine the primary source of the information. If the section is mostly standard boilerplate from the knowledge base, set the 'source' to 'Knowledge Base'. Otherwise, set it to 'AI-generated'.
3.  If you use any information from the knowledge base, you MUST list the exact, verbatim excerpts from the knowledge base that you used in the 'knowledgeBaseExcerpts' array.

Proposal Outline:
{{{proposalOutline}}}

RFP Content: 
{{{rfpContent}}}

Knowledge Base:
{{{knowledgeBaseContent}}}

Generate the drafts for all sections now.`,
});

const draftProposalSectionsFlow = ai.defineFlow(
  {
    name: 'draftProposalSectionsFlow',
    inputSchema: DraftProposalSectionsInputSchema,
    outputSchema: DraftProposalSectionsOutputSchema,
  },
  async input => {
    const {output} = await draftProposalSectionsPrompt(input);
    return output!;
  }
);
