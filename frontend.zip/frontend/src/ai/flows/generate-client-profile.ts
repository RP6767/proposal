'use server';

/**
 * @fileOverview This flow generates a client profile, identifies potential incumbents and competitors,
 * and highlights the client's pain points based on the uploaded RFP documents.
 *
 * - generateClientProfile - A function that generates the client profile.
 * - GenerateClientProfileInput - The input type for the generateClientProfile function.
 * - GenerateClientProfileOutput - The return type for the generateClientProfile function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateClientProfileInputSchema = z.object({
  rfpContent: z
    .string()
    .describe('The content of the RFP document.'),
  knowledgeBaseContent: z.string().optional().describe('Relevant content from the knowledge base to incorporate into the profile.'),
});
export type GenerateClientProfileInput = z.infer<typeof GenerateClientProfileInputSchema>;

const SectionSchema = z.object({
    content: z.string().describe("The analysis for the section. MUST be a bulleted list using Markdown (e.g., '- Item 1\\n- Item 2'). Each point MUST be on a new line."),
    source: z.enum(['AI-generated', 'Knowledge Base']).describe('The primary source of the content for this section.'),
});

const GenerateClientProfileOutputSchema = z.object({
  clientProfile: SectionSchema,
  incumbentVendors: SectionSchema,
  knownCompetitors: SectionSchema,
  painPoints: SectionSchema,
  stakeholderLandscape: SectionSchema,
  strategicTakeaways: SectionSchema,
});
export type GenerateClientProfileOutput = z.infer<typeof GenerateClientProfileOutputSchema>;

export async function generateClientProfile(input: GenerateClientProfileInput): Promise<GenerateClientProfileOutput> {
  return generateClientProfileFlow(input);
}

const generateClientProfilePrompt = ai.definePrompt({
  name: 'generateClientProfilePrompt',
  input: {schema: GenerateClientProfileInputSchema},
  output: {schema: GenerateClientProfileOutputSchema},
  prompt: `You are a strategic analyst for a government contractor named vTech. Your task is to analyze the provided Request for Proposal (RFP) and generate a detailed capture plan.

Use only real, cited data if possible. Keep writing clear, concise, and strategic. No generic answers. Do not fabricate insights. 

For every field in your output, you MUST format the response as a bulleted list using Markdown.
- Start each point with a hyphen.
- Each point MUST be on a new line. Do not combine points into a single paragraph.

When knowledge base content is provided, you must use it to inform your analysis, especially for the Strategic Takeaways section by aligning them with vTech's capabilities.
For each section, determine the primary source of the information. If the section is mostly an objective analysis of the RFP, set the 'source' to 'AI-generated'. If the section's insights are directly derived from the provided knowledge base (e.g., creating win themes based on company strengths), set the 'source' to 'Knowledge Base'.

Analyze the RFP content and provide the following information:

1.  **Client Profile**
    *   Mission, strategic priorities, or digital goals from recent plans
    *   Technology strategy, IT roadmaps, modernization focus
    *   Leadership structure or recent statements aligning to RFP

2.  **Incumbent Vendor(s)**
    *   Current or past vendor(s) for similar work
    *   Contract number, duration, value
    *   Performance indicators (extensions, audits, renewals, feedback)
    *   Example: “XYZ Technologies has delivered helpdesk services under Contract #ABC123 since 2021; reports show 98% SLA compliance.” (Source: [link])

3.  **Known Competitors**
    *   Firms who have bid or are likely to bid
    *   Strengths/weaknesses based on past awards, staff, pricing, approach
    *   Any teaming activity, alliances, or local partnerships
    *   Example: “ABC Corp regularly partners with AWS for cloud RFPs and uses offshore delivery centers to undercut pricing.” (Source: [link])

4.  **Pain Points / Gaps**
    *   Public complaints, audits, user dissatisfaction
    *   Agency statements about issues to fix
    *   Legislative or regulatory triggers for the procurement
    *   Example: “2022 audit flagged gaps in cybersecurity logging and delayed patch management.” (Source: [link])

5.  **Stakeholder Landscape**
    *   Key officials, IT leadership, program managers
    *   Their roles and recent public remarks
    *   Budgetary, political, or regional influences on award
    *   Example: “CIO Jane Doe emphasized digital equity for rural users in March 2024 legislative hearing.” (Source: [link])

6.  **Strategic Takeaways**
    *   List 3–5 actionable win themes vTech should prioritize in this response:
    *   What value themes align with the agency’s goals?
    *   Where does vTech clearly differentiate (certifications, delivery model, past performance)?
    *   Any price-to-win strategies or teaming recommendations?
    *   Example: “Emphasize our SBA 8(a) status and low-risk delivery proven with the City of Jacksonville IT Helpdesk project.”

RFP Content:
{{{rfpContent}}}

{{#if knowledgeBaseContent}}
Knowledge Base:
{{{knowledgeBaseContent}}}
{{/if}}
`,
});

const generateClientProfileFlow = ai.defineFlow(
  {
    name: 'generateClientProfileFlow',
    inputSchema: GenerateClientProfileInputSchema,
    outputSchema: GenerateClientProfileOutputSchema,
  },
  async input => {
    const {output} = await generateClientProfilePrompt(input);
    return output!;
  }
);
