'use server';
/**
 * @fileOverview Generates a compliance matrix from RFP content.
 *
 * - generateComplianceMatrix - A function that creates a compliance matrix.
 * - GenerateComplianceMatrixInput - The input type for the function.
 * - GenerateComplianceMatrixOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateComplianceMatrixInputSchema = z.object({
  rfpContent: z.string().describe('The content of the RFP document.'),
  knowledgeBaseContent: z.string().optional().describe('Relevant content from the knowledge base to inform the matrix.'),
});
export type GenerateComplianceMatrixInput = z.infer<typeof GenerateComplianceMatrixInputSchema>;

const MatrixRowSchema = z.object({
  rfpSection: z.string().describe("The specific section number or identifier from the RFP (e.g., '3.1.2', 'C.5.1')."),
  requirementSummary: z.string().describe("The exact requirement text copied from the RFP."),
  painPoint: z.string().describe("The underlying need or problem the agency is trying to solve with this requirement."),
  proposalSection: z.string().describe("The corresponding section in our proposal where this requirement is addressed (e.g., 'Technical Approach', '4.2')."),
  vtechSolution: z.string().describe("A summary of how vTech's solution satisfies the requirement in plain terms."),
  keyDifferentiator: z.string().describe("Our unique competitive edge for this requirement (e.g., specific certifications, proprietary tools, relevant past performance)."),
  compliant: z.enum(['Y', 'N']).describe("Whether we are fully compliant with the requirement (Yes/No)."),
  clarifications: z.string().describe("Any assumptions made, constraints identified, or innovative approaches proposed. If none, state 'None'."),
  priceToWinStrategy: z.string().describe("Notes on cost-efficiency, areas for value-add, or justification for premium pricing related to this requirement."),
});

const GenerateComplianceMatrixOutputSchema = z.object({
  complianceMatrix: z.array(MatrixRowSchema),
});
export type GenerateComplianceMatrixOutput = z.infer<typeof GenerateComplianceMatrixOutputSchema>;
export type ComplianceMatrixRow = z.infer<typeof MatrixRowSchema>;


export async function generateComplianceMatrix(input: GenerateComplianceMatrixInput): Promise<GenerateComplianceMatrixOutput> {
  return generateComplianceMatrixFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateComplianceMatrixPrompt',
  input: {schema: GenerateComplianceMatrixInputSchema},
  output: {schema: GenerateComplianceMatrixOutputSchema},
  prompt: `You are an AI assistant tasked with creating a comprehensive compliance matrix for a Request for Proposal (RFP).

Analyze the provided RFP content and knowledge base information. For EACH requirement, create a row in the compliance matrix.

**Instructions:**
- **Requirement Summary:** Copy the exact language from the RFP for each requirement.
- **Pain Point / Need:** Infer the agency's underlying problem or goal for each requirement.
- **Proposal Section:** Identify where in our proposal we will address this.
- **vTech Solution Summary:** Briefly explain how our solution meets the requirement. Use the knowledge base to inform this.
- **Key Differentiator:** What is our competitive edge? Use the knowledge base for our certifications, tools, or past performance.
- **Compliant (Y/N):** State 'Y' or 'N'.
- **Clarifications / Assumptions:** Note any dependencies, constraints, or innovations.
- **Price-to-Win Strategy Input:** Identify areas for cost-efficiency, value-adds, or premium pricing justification.

RFP Content:
{{{rfpContent}}}

{{#if knowledgeBaseContent}}
Knowledge Base:
{{{knowledgeBaseContent}}}
{{/if}}
`,
});

const generateComplianceMatrixFlow = ai.defineFlow(
  {
    name: 'generateComplianceMatrixFlow',
    inputSchema: GenerateComplianceMatrixInputSchema,
    outputSchema: GenerateComplianceMatrixOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
