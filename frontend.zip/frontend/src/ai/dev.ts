import { config } from 'dotenv';
config();

import '@/ai/flows/draft-proposal-sections.ts';
import '@/ai/flows/analyze-rfp-content.ts';
import '@/ai/flows/generate-client-profile.ts';
import '@/ai/flows/answer-rfp-questions.ts';
import '@/ai/flows/generate-proposal-outline.ts';
import '@/ai/flows/generate-compliance-matrix.ts';
