'use client';

import { useState, useEffect } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { ChevronDown, Check, Database, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';

import { nanoid } from 'nanoid'

interface GapAnalysisCardProps {
  proposalId: string;
}

const GapAnalysisCardContent = ({ proposalId }: GapAnalysisCardProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [sources, setSources] = useState<string[]>([]);
  const [selectedSources, setSelectedSources] = useState<string[]>([]);
  const [analyzedSources, setAnalyzedSources] = useState<string[]>([]); // 👈 keep track of sources used for analysis
  const [loadingKnowledge, setLoadingKnowledge] = useState(false);
  const [loadingAnalysis, setLoadingAnalysis] = useState(false);
  const [saving, setSaving] = useState(false);
  const [gapAnalysis, setGapAnalysis] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [alreadySaved, setAlreadySaved] = useState(false);

  // Fetch knowledge sources
  useEffect(() => {
    const fetchKnowledge = async () => {
      setLoadingKnowledge(true);
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/knowledge`);
        if (!res.ok) throw new Error(`Error fetching knowledge: ${res.statusText}`);
        const data = await res.json();
        const uniqueSources = Array.from(  new Set(data.map((item: any) => String(item.source)))) as string[];
        setSources(uniqueSources);
      } catch (err: any) {
        setError(err.message ?? 'Unknown error while fetching knowledge.');
      } finally {
        setLoadingKnowledge(false);
      }
    };
    fetchKnowledge();
  }, []);

  // Fetch saved analysis if exists
  useEffect(() => {
    if (!proposalId) return;
    const fetchSavedAnalysis = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/proposals/${proposalId}/analysis`);
        if (!res.ok) throw new Error(await res.text());
        const data = await res.json();
        const savedGap = data?.analysis?.gapAnalysis;
        if (savedGap && Object.keys(savedGap).length > 0) {
          setSelectedSources([]);
          const firstSource = Object.keys(savedGap)[0];
          setGapAnalysis(savedGap[firstSource]);
          setIsOpen(true);
          setAlreadySaved(true);
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchSavedAnalysis();
  }, [proposalId]);

  // Analyze Gap
  const handleAnalyze = async () => {
    if (!proposalId || selectedSources.length === 0) {
      setError('Proposal ID or knowledge sources are missing.');
      return;
    }
    setGapAnalysis(null);
    setError(null);
    setLoadingAnalysis(true);

    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/proposals/${proposalId}/gap-analysis`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ knowledgeSources: selectedSources }),
      });
      if (!res.ok) throw new Error(await res.text() || 'Failed gap analysis');

      const data = await res.json();
      setGapAnalysis(data.analysis);
      setIsOpen(true);
      setAlreadySaved(false);
      setAnalyzedSources(selectedSources); // 👈 remember which were analyzed
      setSelectedSources([]); // clear UI
    } catch (err: any) {
      setError(err.message ?? 'Unknown error during gap analysis.');
    } finally {
      setLoadingAnalysis(false);
    }
  };

  // Save Gap Analysis
  const handleSave = async () => {
    if (!proposalId || !gapAnalysis) return;

    setSaving(true);
    setError(null);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/proposals/${proposalId}/gap-analysis/save`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          // 👇 send as a string (comma-separated) to avoid "unhashable type: 'list'"
          knowledgeSource: analyzedSources.join(', '),
          analysis: gapAnalysis,
        }),
      });
      if (!res.ok) throw new Error(await res.text() || 'Failed saving gap analysis');
      alert('Gap analysis saved successfully.');
      setAlreadySaved(true);
    } catch (err: any) {
      setError(err.message ?? 'Unknown error while saving gap analysis.');
    } finally {
      setSaving(false);
    }
  };

  // Toggle Select All / Clear All
  const handleToggleAll = () => {
    if (selectedSources.length === sources.length) {
      setSelectedSources([]);
      setGapAnalysis(null);
    } else {
      setSelectedSources(sources);
    }
  };

  return (
    <div className="mb-6">
      {/* Layout header */}
      <div className="flex items-center justify-between w-full mx-auto mb-4">
        <h2 className="text-lg font-semibold">Gap Analysis</h2>

        {/* Dropdown */}
        <div className="flex-1 mx-24">
  {loadingKnowledge ? (
    <Skeleton className="h-10 w-full max-w-xs mx-auto" />
  ) : (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          disabled={!proposalId}
          className="w-full max-w-xs justify-between mx-auto border rounded px-3 py-2 flex items-center"
        >
          {selectedSources.length > 0
            ? `${selectedSources.length} source(s) selected`
            : 'Select Knowledge Sources'}
          <ChevronDown className="ml-2 h-4 w-4 opacity-50" />
        </button>
      </PopoverTrigger>

      <PopoverContent className="w-64 p-0">
        <div className="max-h-60 overflow-y-auto">
          {/* Select / Clear All */}
          <button
            type="button"
            onClick={handleToggleAll}
            className="w-full px-3 py-2 text-sm font-medium text-blue-600 text-left hover:bg-gray-100"
          >
            {selectedSources.length === sources.length ? 'Clear All' : 'Select All'}
          </button>

          {/* Individual sources */}
          {sources.map((source) => {
            const isSelected = selectedSources.includes(source);
            const key = source || nanoid();
            return (
              <label
                key={key}
                className="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-gray-100"
              >
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => {
                    const newSelected = isSelected
                      ? selectedSources.filter((s) => s !== source)
                      : [...selectedSources, source];
                    setSelectedSources(newSelected);
                    if (!alreadySaved && newSelected.length === 0) setGapAnalysis(null);
                  }}
                  className="h-4 w-4 rounded-sm border-gray-400"
                />
                <span className="text-sm">{source}</span>
              </label>
            );
          })}
        </div>
      </PopoverContent>
    </Popover>
  )}
</div>


        {/* Right badge */}
        <Badge variant="default" className="text-sm flex items-center gap-1">
          <Database className="w-3 h-3" />
          Knowledge Based
        </Badge>
      </div>

      {/* Analyze button */}
      {selectedSources.length > 0 && (
        <div className="flex justify-center mb-4">
          <Button onClick={handleAnalyze} disabled={!proposalId || loadingAnalysis}>
            {loadingAnalysis ? 'Analyzing...' : 'Analyze Gap'}
          </Button>
        </div>
      )}

      {/* Results + Save */}
      {isOpen && gapAnalysis && (
        <div className="prose prose-sm dark:prose-invert max-w-none">
          {error ? (
            <p className="text-red-500">{error}</p>
          ) : (
            <div>
              <h3 className="flex items-center gap-2">
                The AI-generated evaluation of your capabilities against the RFP requirements.
                <Popover>
                  <PopoverTrigger asChild>
                    <Info className="w-5 h-5 text-blue-600 cursor-pointer" />
                  </PopoverTrigger>
                  <PopoverContent
                    side="left"
                    align="start"
                    sideOffset={8}
                    className="w-80 p-4 text-sm mt-6"
                  >
                    <h4 className="font-bold mb-2">Scoring Legend</h4>
                    <ul className="list-disc pl-5 space-y-1">
                      <li><strong>4</strong> — Strong past performance/capabilities with full coverage</li>
                      <li><strong>3</strong> — Strong performance/capabilities with a federal customer</li>
                      <li><strong>2</strong> — Partial coverage of capabilities with a federal customer</li>
                      <li><strong>1</strong> — Little or no experience</li>
                    </ul>
                  </PopoverContent>
                </Popover>
              </h3>

              <h4 className="font-bold">Proposal Metadata</h4>
              <p><strong>RFP Number:</strong> {gapAnalysis.metadata?.rfpNumber ?? 'Null'}</p>
              <p><strong>Project Title:</strong> {gapAnalysis.metadata?.projectTitle ?? 'Null'}</p>
              <p><strong>Facility Clearance:</strong> {gapAnalysis.metadata?.facilityClearance ?? 'Null'}</p>
              <p><strong>Security Clearance:</strong> {gapAnalysis.metadata?.securityClearance ?? 'Null'}</p>
              <p><strong>Other Concerns:</strong> 
                {gapAnalysis.metadata?.otherConcerns?.length
                  ? gapAnalysis.metadata.otherConcerns.join(', ')
                  : 'Null'}
              </p>
              <p><strong>Business Types:</strong> 
                {gapAnalysis.metadata?.businessTypes?.length
                  ? gapAnalysis.metadata.businessTypes.join(', ')
                  : 'Null'}
              </p>


              <h4 className="font-bold mt-6 mb-2">Scorecard Analysis</h4>
              <table className="w-full border border-gray-300 text-sm">
                <thead className="bg-gray-100">
  <tr>
   <th className="border p-2 text-center align-middle">Functional Area</th>
      <th className="border p-2 text-center align-middle">Task</th>
      <th className="border p-2 text-center align-middle">Experience</th>
      <th className="border p-2 text-center align-middle">Writing</th>
      <th className="border p-2 text-center align-middle">Customer Exp</th>
      <th className="border p-2 text-center align-middle">Comments</th>
  </tr>
</thead>

                <tbody>
  {gapAnalysis.scorecard?.map((row: any) => (
    <tr key={row.id}>
      <td className="border p-2">{row.functionalArea}</td>
      <td className="border p-2">{row.task}</td>
      <td className="border p-2 text-center">{row.expCapabilityScore}</td>
      <td className="border p-2 text-center">{row.writingCapabilityScore}</td>
      <td className="border p-2 text-center">{row.customerExperienceScore}</td>
      <td className="border p-2">{row.comments}</td>
    </tr>
  ))}
</tbody>

              </table>

              {!alreadySaved && (
                <Button onClick={handleSave} disabled={saving} className="mt-4">
                  {saving ? 'Saving...' : 'Save Gap Analysis'}
                </Button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default GapAnalysisCardContent;
