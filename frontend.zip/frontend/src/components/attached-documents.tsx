'use client';

import React, { useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Paperclip, Plus, Trash2, FileText, File, FileCode, Loader2 } from 'lucide-react';
import { nanoid } from 'nanoid';
import { useToast } from '@/hooks/use-toast';
import type { AttachedDocument } from '@/types';

// Loading dialog while AI re-analyzes
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

function AnalysisLoadingDialog({ open }: { open: boolean }) {
  return (
    <Dialog open={open}>
      <DialogContent className="flex flex-col items-center justify-center space-y-4">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <DialogHeader>
          <DialogTitle>Analyzing documents…</DialogTitle>
          <p className="text-sm text-muted-foreground">
            Our AI is updating the proposal analysis. This may take a moment.
          </p>
        </DialogHeader>
      </DialogContent>
    </Dialog>
  );
}

interface AttachedDocumentsProps {
  docs: AttachedDocument[];
  setDocs: React.Dispatch<React.SetStateAction<AttachedDocument[]>>;
  proposalId: string;
}

export function AttachedDocuments({ docs, setDocs, proposalId }: AttachedDocumentsProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const getFileIcon = (filename: string) => {
    const ext = filename.split('.').pop()?.toLowerCase();
    if (!ext) return <File className="h-5 w-5 text-muted-foreground" />;
    if (['doc', 'docx', 'pdf', 'txt', 'rtf'].includes(ext)) {
      return <FileText className="h-5 w-5 text-blue-500" />;
    }
    if (['js', 'ts', 'tsx', 'json', 'py', 'java', 'c', 'cpp', 'cs'].includes(ext)) {
      return <FileCode className="h-5 w-5 text-green-500" />;
    }
    return <File className="h-5 w-5 text-muted-foreground" />;
  };

 const handleFileAdd = async (event: React.ChangeEvent<HTMLInputElement>) => {
  const files = event.target.files;
  if (!files || files.length === 0) return;

  const apiUrl = process.env.NEXT_PUBLIC_API_URL;
  const formData = new FormData();
  Array.from(files).forEach(file => formData.append('files', file));

  try {
    setIsAnalyzing(true);

    const res = await fetch(`${apiUrl}/api/proposals/${proposalId}/files`, {
      method: 'POST',
      body: formData,
    });

    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error ?? 'Failed to upload files');
    }

    const { newFiles, analysis } = await res.json();

    setDocs(prev => [...prev, ...newFiles]);

    // Optional: dispatch analysisUpdated
    document.dispatchEvent(new CustomEvent("analysisUpdated", { detail: analysis }));

    toast({
      title: `${newFiles.length} document(s) added and analysis updated.`,
    });

    // 🔥 Full page refresh
    window.location.reload();

  } catch (err: any) {
    toast({
      variant: 'destructive',
      title: 'Upload Failed',
      description: err.message ?? 'Could not upload files',
    });
  } finally {
    setIsAnalyzing(false);
  }
};


const handleFileDelete = async (docId: string) => {
  try {
    setIsAnalyzing(true);

    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/proposals/${proposalId}/files/${docId}`, {
      method: 'DELETE',
    });

    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error ?? 'Failed to delete file');
    }

    const { analysis } = await res.json();

    setDocs(prev => prev.filter(d => d.id !== docId));

    document.dispatchEvent(new CustomEvent("analysisUpdated", { detail: analysis }));

    toast({ title: 'Document removed and analysis updated.' });

    // 🔥 Full page refresh
    window.location.reload();

  } catch (err: any) {
    toast({
      variant: 'destructive',
      title: 'Delete Failed',
      description: err.message ?? 'Could not delete file',
    });
  } finally {
    setIsAnalyzing(false);
  }
};


  return (
    <>
      <Card className="sticky top-24">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Paperclip className="h-5 w-5" />
            Attached Documents
          </CardTitle>
          <CardDescription>Upload and manage reference documents for proposal analysis.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {docs.length === 0 && (
              <p className="text-sm text-muted-foreground">No documents attached yet.</p>
            )}
            {docs.map(doc => (
              <div
                key={doc.id ?? nanoid()}
                className="flex items-center justify-between rounded-lg border p-2"
              >
                <div className="flex items-center gap-2">
                  {getFileIcon(doc.name)}
                  <span className="text-sm font-medium">{doc.name}</span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleFileDelete(doc.id)}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            ))}

            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              multiple
              onChange={handleFileAdd}
            />
            <Button
              variant="outline"
              className="w-full"
              onClick={() => fileInputRef.current?.click()}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Document
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* AI Analysis Loading Dialog */}
      <AnalysisLoadingDialog open={isAnalyzing} />
    </>
  );
}
