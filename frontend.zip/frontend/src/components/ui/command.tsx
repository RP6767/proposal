"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

export const Command = ({ children, className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("p-2 border rounded-md bg-background", className)} {...props}>
    {children}
  </div>
);

export const CommandGroup = ({ children, className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("mt-2 space-y-1", className)} {...props}>
    {children}
  </div>
);

export const CommandItem = ({ children, className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("cursor-pointer p-2 hover:bg-muted rounded-md", className)} {...props}>
    {children}
  </div>
);
