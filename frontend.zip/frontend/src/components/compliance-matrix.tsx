'use client';

import * as React from 'react';
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from '@tanstack/react-table';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { CheckCircle2, XCircle } from 'lucide-react';


export const columns: ColumnDef<ComplianceMatrixRow>[] = [
  {
    accessorKey: 'rfpSection',
    header: 'RFP Section/ID',
    cell: ({ row }) => <div className="font-medium">{row.getValue('rfpSection')}</div>,
  },
  {
    accessorKey: 'requirementSummary',
    header: 'Requirement Summary',
    cell: ({ row }) => <div className="text-muted-foreground max-w-xs break-words whitespace-pre-wrap">{row.getValue('requirementSummary')}</div>,
  },
  {
    accessorKey: 'painPoint',
    header: 'Pain Point / Need',
    cell: ({ row }) => <div className="text-muted-foreground max-w-xs break-words whitespace-pre-wrap">{row.getValue('painPoint')}</div>,
  },
  {
    accessorKey: 'proposalSection',
    header: 'Proposal Section',
  },
  {
    accessorKey: 'vtechSolution',
    header: 'vTech Solution Summary',
    cell: ({ row }) => <div className="text-muted-foreground max-w-xs break-words whitespace-pre-wrap">{row.getValue('vtechSolution')}</div>,
  },
  {
    accessorKey: 'keyDifferentiator',
    header: 'Key Differentiator',
    cell: ({ row }) => <div className="text-muted-foreground max-w-xs break-words whitespace-pre-wrap">{row.getValue('keyDifferentiator')}</div>,
  },
  {
    accessorKey: 'compliant',
    header: 'Compliant',
    cell: ({ row }) => {
      const isCompliant = row.getValue('compliant') === 'Y';
      return isCompliant ? <CheckCircle2 className="text-green-500" /> : <XCircle className="text-red-500" />;
    },
  },
  {
    accessorKey: 'clarifications',
    header: 'Clarifications / Assumptions',
    cell: ({ row }) => <div className="text-muted-foreground max-w-xs break-words whitespace-pre-wrap">{row.getValue('clarifications')}</div>,
  },
  {
    accessorKey: 'priceToWinStrategy',
    header: 'Price-to-Win Strategy',
    cell: ({ row }) => <div className="text-muted-foreground max-w-xs break-words whitespace-pre-wrap">{row.getValue('priceToWinStrategy')}</div>,
  },
];


type ComplianceMatrixProps = {
  data: ComplianceMatrixRow[];
};

export function ComplianceMatrix({ data }: ComplianceMatrixProps) {
  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
  });

  return (
    <Card>
        <CardHeader>
            <CardTitle>Compliance Matrix</CardTitle>
            <CardDescription>
                A detailed breakdown of RFP requirements, our proposed solutions, and strategic analysis.
            </CardDescription>
        </CardHeader>
        <CardContent>
            <div className="rounded-md border">
                <Table>
                <TableHeader>
                    {table.getHeaderGroups().map((headerGroup) => (
                    <TableRow key={headerGroup.id}>
                        {headerGroup.headers.map((header) => {
                        return (
                            <TableHead key={header.id} style={{ width: header.getSize() }}>
                            {header.isPlaceholder
                                ? null
                                : flexRender(
                                    header.column.columnDef.header,
                                    header.getContext()
                                )}
                            </TableHead>
                        );
                        })}
                    </TableRow>
                    ))}
                </TableHeader>
                <TableBody>
                    {table.getRowModel().rows?.length ? (
                    table.getRowModel().rows.map((row) => (
                        <TableRow
                        key={row.id}
                        data-state={row.getIsSelected() && 'selected'}
                        >
                        {row.getVisibleCells().map((cell) => (
                            <TableCell key={cell.id} style={{ width: cell.column.getSize() }}>
                            {flexRender(cell.column.columnDef.cell, cell.getContext())}
                            </TableCell>
                        ))}
                        </TableRow>
                    ))
                    ) : (
                    <TableRow>
                        <TableCell colSpan={columns.length} className="h-24 text-center">
                        No results.
                        </TableCell>
                    </TableRow>
                    )}
                </TableBody>
                </Table>
            </div>
      </CardContent>
    </Card>
  );
}
