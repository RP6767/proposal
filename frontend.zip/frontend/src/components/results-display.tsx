
'use client';

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TabLabel } from './TabLabel'; // adjust path

import type {
  AnalyzeRFPContentOutput,
  GenerateClientProfileOutput,
  DraftProposalSectionsOutput,
  GenerateComplianceMatrixOutput,
  OutlineSection,
  ProposalSection,
  AnalysisSection,
} from '@/lib/types';
import GapAnalysisCardContent from './GapAnalysisCard';

import {
  FileText,
  Target,
  FileSignature,
  BookMarked,
  Sparkles,
  Loader2,
  ClipboardCopy,
  Plus,
  Trash2,
  Download,
  GripVertical,
  RefreshCw,
  Eye,
  Database,
  BrainCircuit,
  ListChecks,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import React, { useState, useEffect } from 'react';
import { Input } from './ui/input';
import { Packer, Document, Paragraph, TextRun, HeadingLevel } from 'docx';
import { saveAs } from 'file-saver';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import { ComplianceMatrix } from './compliance-matrix';


type LoadingStates = {
  analysis: boolean;
  capture: boolean;
  outline: boolean;
  draft: boolean;
  compliance: boolean;
};
interface TabLabelProps {
  icon: React.ElementType;
  label: string;
  loading: boolean;
}

type ResultsDisplayProps = {
   proposalId: string;
  analysisResult: AnalyzeRFPContentOutput | null;
  captureResult: GenerateClientProfileOutput | null;
  proposalDraft: DraftProposalSectionsOutput | null;
  complianceMatrix: GenerateComplianceMatrixOutput | null;
  onGenerateDraft: (outline: string) => void;
  isLoading: LoadingStates;
  rfpContent: string;
  knowledgeBaseContent: string;
};

const SectionSourceBadge = ({ source }: { source: AnalysisSection['source'] }) => (
    <Badge variant={source === 'Knowledge Base' ? 'default' : 'secondary'} className='text-xs absolute top-3 right-4'>
        {source === 'Knowledge Base' ? <Database className="w-3 h-3 mr-1.5" /> : <BrainCircuit className="w-3 h-3 mr-1.5" />}
        {source}
    </Badge>
);



const SectionCard = ({
  title,
  children,
  isLoading,
  source,
   className,

}: {
  title: string;
  children: React.ReactNode;
  isLoading: boolean;
  source?: AnalysisSection['source'];
   className?: string;
}) => (
  <Card className={cn("relative shadow-md", className)}>
    <CardHeader>
      <CardTitle className="text-lg pr-28">{title}</CardTitle>
      {source && !isLoading && <SectionSourceBadge source={source} />}
    </CardHeader>
    <CardContent className="prose prose-sm dark:prose-invert max-w-none">
      {isLoading ? (
        <div className="space-y-2">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
        </div>
      ) : (
        <div className="text-muted-foreground whitespace-pre-line">{children}</div>
      )}
    </CardContent>
  </Card>
);
const AnalysisContent = ({
  result,
  isLoading,
  proposalId, 
}: {
  result: AnalyzeRFPContentOutput| null;
  isLoading: boolean;
  proposalId: string; // add type
}) => {
  if (isLoading) return <p>Loading analysis…</p>;
  if (!result) return <p>No analysis available yet.</p>;

  return (
    <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
 <SectionCard title="Key Requirements" source={result.keyRequirementsSource ?? 'AI-generated'}>
  {result.keyRequirements?.length ? (
    <ul>
      {result.keyRequirements.map((req: string) => (
        <li key={req}>{req}</li> // use the requirement string itself as key
      ))}
    </ul>
  ) : (
    "No key requirements found."
  )}
</SectionCard>


<SectionCard
  title="Project Scope"
  source={result.keyRequirementsSource ?? "AI-generated"}
>
  <div className="space-y-3 leading-relaxed">
    {(result.projectScope ?? "No project scope available.")
      .split(/\n+/)
      .map((para) => (
        <p key={para}>{para}</p> // use paragraph content as key
      ))}
  </div>
</SectionCard>




           <SectionCard title="Important Deadlines" source={result.keyRequirementsSource ?? 'AI-generated'}>
  {result.importantDeadlines?.length ? (
    <ul>
     {result.importantDeadlines?.map((dl) => (
  <li key={`${dl.date}-${dl.description}`}> {/* stable, unique key */}
    <strong>{dl.date}</strong>: {dl.description}
  </li>
))}

    </ul>
  ) : (
    "No deadlines provided."
  )}
</SectionCard>


            <SectionCard title="Evaluation Criteria" source={result.keyRequirementsSource ?? 'AI-generated'}>
  {result.evaluationCriteria?.length ? (
    <ul>
      {result.evaluationCriteria.map((c: string) => (
        <li key={c}>{c}</li> // use the string itself as a unique key
      ))}
    </ul>
  ) : (
    "No evaluation criteria available."
  )}
</SectionCard>


        <Card className="lg:col-span-2 p-6 ">
          {proposalId ? <GapAnalysisCardContent proposalId={proposalId} /> : (
            <p className="text-red-500 text-center py-4">
              Proposal ID is missing. Cannot perform gap analysis.
            </p>
          )}
        </Card>

    </div>
  );
};


const CaptureContent = ({
  result,
  isLoading,
}: {
  result: GenerateClientProfileOutput | null;
  isLoading: boolean;
}) => (
    <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
    <SectionCard title="Client Profile" isLoading={isLoading} source={result?.clientProfile.source}>
      {result?.clientProfile.content}
    </SectionCard>
    <SectionCard title="Pain Points / Gaps" isLoading={isLoading} source={result?.gapAnalysis.source}>
      {result?.painPoints.content}
    </SectionCard>
    <SectionCard title="Incumbent Vendor(s)" isLoading={isLoading} source={result?.incumbentVendors.source}>
      {result?.incumbentVendors.content}
    </SectionCard>
    <SectionCard title="Known Competitors" isLoading={isLoading} source={result?.competitors.source}>
      {result?.knownCompetitors.content}
    </SectionCard>
    <SectionCard title="Stakeholder Landscape" isLoading={isLoading} source={result?.stakeholders.source}>
      {result?.stakeholderLandscape.content}
    </SectionCard>
    <SectionCard title="Strategic Takeaways" isLoading={isLoading} source={result?.strategicTakeaways.source}>
      {result?.strategicTakeaways.content}
    </SectionCard>
  </div>
);

const ComplianceContent = ({
    result,
    isLoading
}: {
    result: GenerateComplianceMatrixOutput | null;
    isLoading: boolean;
}) => {
    if (isLoading) {
        return (
            <div className="grid gap-6">
                 <Card>
                    <CardHeader>
                        <CardTitle>Generating Compliance Matrix...</CardTitle>
                    </CardHeader>
                    <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                        <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
                        <p className="text-muted-foreground">The AI is building the compliance matrix based on your RFP.</p>
                    </CardContent>
                </Card>
            </div>
        )
    }

    if (!result) {
        return (
             <div className="flex flex-col items-center justify-center text-center py-12 border-dashed border-2 rounded-lg bg-muted/20">
                <ListChecks className="w-16 h-16 text-muted-foreground/50 mb-4" />
                <h3 className="text-xl font-semibold">No Compliance Matrix Data</h3>
                <p className="text-muted-foreground mt-2">
                  The compliance matrix could not be generated. This may happen if the RFP analysis fails.
                </p>
            </div>
        )
    }

    return (
        <ComplianceMatrix data={result.complianceMatrix} />
    )
};


const OutlineContent = ({
  onGenerate,
  isLoading,
  rfpContent,
  knowledgeBaseContent
}: {
  onGenerate: (outline: string) => void;
  isLoading: boolean;
  rfpContent: string;
  knowledgeBaseContent: string;
}) => {
    const { toast } = useToast();
    const [outlineSections, setOutlineSections] = useState<OutlineSection[]>([]);
    const [isGeneratingOutline, setIsGeneratingOutline] = useState(true);
    const [newSectionTitle, setNewSectionTitle] = useState('');
    const [draggedItem, setDraggedItem] = useState<OutlineSection | null>(null);
    
    const fetchOutline = async () => {
        setIsGeneratingOutline(true);
        try {
            const result = await generateProposalOutline({ rfpContent, knowledgeBaseContent });
            setOutlineSections(result.outline);
        } catch (error) {
            console.error("Failed to generate outline:", error);
            toast({
                variant: 'destructive',
                title: 'Outline Generation Failed',
                description: 'Could not generate a tailored outline. Please try again.',
            });
        } finally {
            setIsGeneratingOutline(false);
        }
    }

    useEffect(() => {
        if(rfpContent) {
            fetchOutline();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [rfpContent, knowledgeBaseContent]);


    const handleAddSection = () => {
        if (newSectionTitle.trim() === '') return;
        const newSection: OutlineSection = {
            id: Date.now(),
            title: newSectionTitle.trim(),
            description: 'Custom section added by user.',
        };
        setOutlineSections([...outlineSections, newSection]);
        setNewSectionTitle('');
    };

    const handleRemoveSection = (id: number) => {
        setOutlineSections(outlineSections.filter(section => section.id !== id));
    };

    const handleDragStart = (e: React.DragEvent<HTMLLIElement>, item: OutlineSection) => {
        setDraggedItem(item);
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/html', e.currentTarget.toString());
    };

    const handleDragOver = (e: React.DragEvent<HTMLLIElement>, item: OutlineSection) => {
        e.preventDefault();
        if (draggedItem === null || draggedItem.id === item.id) return;
        
        const items = Array.from(outlineSections);
        const draggedIndex = items.findIndex(i => i.id === draggedItem.id);
        const targetIndex = items.findIndex(i => i.id === item.id);
        
        items.splice(draggedIndex, 1);
        items.splice(targetIndex, 0, draggedItem);
        setOutlineSections(items);
    };

    const handleDragEnd = () => {
        setDraggedItem(null);
    };
    
    const formatOutlineForGeneration = () => {
        return outlineSections.map(s => `- **${s.title}:** ${s.description}`).join('\n');
    }
    
    const handleDownload = () => {
        const doc = new Document({
            sections: [{
                properties: {},
                children: [
                    new Paragraph({
                        text: "Proposal Outline",
                        heading: HeadingLevel.TITLE,
                    }),
                    ...outlineSections.flatMap(section => [
                        new Paragraph({
                            children: [new TextRun({ text: section.title, bold: true })],
                            style: 'ListParagraph',
                            bullet: {
                                level: 0
                            }
                        }),
                        new Paragraph({
                            children: [new TextRun(section.description)],
                            style: 'ListParagraph',
                        }),
                        new Paragraph({ text: "" })
                    ])
                ],
            }],
        });

        Packer.toBlob(doc).then(blob => {
            saveAs(blob, "proposal-outline.docx");
        });
    };

    if (isGeneratingOutline) {
        return (
             <Card>
                <CardHeader>
                    <CardTitle>Generating Proposal Outline...</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                    <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
                    <p className="text-muted-foreground">The AI is analyzing your RFP and Knowledge Base to create a tailored outline.</p>
                </CardContent>
            </Card>
        )
    }

    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Proposal Outline</CardTitle>
                <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={fetchOutline} disabled={isGeneratingOutline}>
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Regenerate
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleDownload} disabled={outlineSections.length === 0}>
                        <Download className="w-4 h-4 mr-2" />
                        Download
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                <ul className="space-y-3">
                    {outlineSections.map((section) => (
                        <li
                            key={section.id}
                            draggable
                            onDragStart={(e) => handleDragStart(e, section)}
                            onDragOver={(e) => handleDragOver(e, section)}
                            onDragEnd={handleDragEnd}
                            className={`p-3 border rounded-lg flex items-center gap-3 transition-all cursor-grab ${draggedItem?.id === section.id ? 'opacity-50 shadow-lg' : ''}`}
                        >
                            <GripVertical className="w-5 h-5 text-muted-foreground" />
                            <div className="flex-1">
                                <strong className="text-foreground font-medium">{section.title}</strong>
                                <p className="text-muted-foreground text-sm">{section.description}</p>
                            </div>
                            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive h-8 w-8" onClick={() => handleRemoveSection(section.id)}>
                                <Trash2 className="w-4 h-4" />
                            </Button>
                        </li>
                    ))}
                </ul>

                <div className="mt-6 flex items-center gap-2">
                    <Input 
                        placeholder="Add new section title..." 
                        value={newSectionTitle}
                        onChange={(e) => setNewSectionTitle(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddSection()}
                    />
                    <Button onClick={handleAddSection} variant="outline" >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Section
                    </Button>
                </div>
                
                <div className="flex justify-end mt-8">
                    <Button
                        onClick={() => onGenerate(formatOutlineForGeneration())}
                        disabled={isLoading || outlineSections.length === 0}
                        size="lg"
                    >
                        {isLoading ? (
                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        ) : (
                            <Sparkles className="w-5 h-5 mr-2" />
                        )}
                        Generate Full Proposal
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
};

const DraftContent = ({
  draft,
  isLoading,
}: {
  draft: DraftProposalSectionsOutput | null;
  isLoading: boolean;
}) => {
  const [showSources, setShowSources] = useState(false);
  const { toast } = useToast();

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-1/3" />
        </CardHeader>
        <CardContent className="space-y-6">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-6 w-1/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!draft) {
    return (
      <div className="flex flex-col items-center justify-center text-center py-12 border-dashed border-2 rounded-lg bg-muted/20">
        <FileSignature className="w-16 h-16 text-muted-foreground/50 mb-4" />
        <h3 className="text-xl font-semibold">No Draft Generated</h3>
        <p className="text-muted-foreground mt-2">
          Go to the &quot;Outline&quot; tab to generate the first draft of the proposal.
        </p>
      </div>
    );
  }

  const sections = [
    { title: 'Executive Summary', data: draft.executiveSummary },
    { title: 'Technical Approach', data: draft.technicalApproach },
    { title: 'Management Approach', data: draft.managementApproach },
    { title: 'Past Performance', data: draft.pastPerformance },
    { title: 'Appendices', data: draft.appendices },
  ];
  
  const HighlightedContent = ({ section }: { section: ProposalSection }) => {
    if (!showSources || section.source !== 'Knowledge Base' || section.knowledgeBaseExcerpts.length === 0) {
      return <p className="whitespace-pre-wrap">{section.content}</p>;
    }
    
    let highlightedText: (string | JSX.Element)[] = [section.content];

    section.knowledgeBaseExcerpts.forEach((excerpt, i) => {
        let tempArr: (string | JSX.Element)[] = [];
        highlightedText.forEach(textPart => {
            if(typeof textPart === 'string') {
                const parts = textPart.split(excerpt);
                parts.forEach((part, index) => {
                    tempArr.push(part);
                    if (index < parts.length - 1) {
                       tempArr.push(<TooltipProvider key={`${i}-${index}`}><Tooltip><TooltipTrigger asChild><mark className="bg-primary/20 text-primary-foreground rounded-sm px-1 py-0.5">{excerpt}</mark></TooltipTrigger><TooltipContent><p>From Knowledge Base</p></TooltipContent></Tooltip></TooltipProvider>);
                    }
                });
            } else {
                tempArr.push(textPart);
            }
        });
        highlightedText = tempArr;
    });

    return <p className="whitespace-pre-wrap">{highlightedText}</p>;
  }

  return (
    <Card>
      <CardHeader className='flex-row items-center justify-between'>
        <CardTitle>Generated Proposal Draft</CardTitle>
        <div className="flex items-center space-x-2">
            <Switch id="show-sources" checked={showSources} onCheckedChange={setShowSources} />
            <Label htmlFor="show-sources" className="flex items-center gap-2"><Eye className="w-4 h-4"/>Show Sources</Label>
        </div>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible defaultValue="item-0">
          {sections.map((section, index) => (
            <AccordionItem value={`item-${index}`} key={index}>
              <AccordionTrigger className="text-base font-semibold hover:no-underline">
                <div className="flex justify-between items-center w-full pr-4">
                    <div className='flex items-center gap-3'>
                        {section.title}
                        <Badge variant={section.data.source === 'Knowledge Base' ? 'default' : 'secondary'} className='text-xs'>
                             {section.data.source === 'Knowledge Base' ? <Database className="w-3 h-3 mr-1.5" /> : <BrainCircuit className="w-3 h-3 mr-1.5" />}
                            {section.data.source}
                        </Badge>
                    </div>
                  <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(section.data.content); toast({title: "Copied to clipboard!"})}} className="text-muted-foreground hover:text-foreground h-7 w-7">
                    <ClipboardCopy className="w-4 h-4" />
                  </Button>
                </div>
              </AccordionTrigger>
              <AccordionContent className="prose prose-sm dark:prose-invert max-w-none text-muted-foreground px-1">
                <HighlightedContent section={section.data} />
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
};




export function ResultsDisplay({
  proposalId,
  analysisResult: initialAnalysisResult,
  captureResult,
  proposalDraft,
  complianceMatrix,
  onGenerateDraft,
  isLoading,
  rfpContent,
  knowledgeBaseContent
}: ResultsDisplayProps) {
  const { toast } = useToast();
  const [analysisResult, setAnalysisResult] = useState<AnalyzeRFPContentOutput | null>(initialAnalysisResult);
 const analysisLoading = isLoading.analysis && !analysisResult;
 const [captureState, setCaptureState] = useState<GenerateClientProfileOutput | null>(captureResult);



// useEffect(() => {
//   if (!proposalId) return;

//   const fetchProposal = async () => {
//     try {
//       const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/proposals/${proposalId}/analysis`);
//       if (!res.ok) {
//         throw new Error(`Failed to fetch proposal: ${res.statusText}`);
//       }

//       const data = await res.json();
//       setAnalysisResult(data.analysis); // only store analysis
//     } catch (error: any) {
//       console.error("Analysis fetch failed:", error);
//       toast({
//         variant: "destructive",
//         title: "Analysis Failed",
//         description: error.message ?? "Could not fetch analysis.",
//       });
//     }
//   };

//   fetchProposal();
// }, [proposalId, toast]);


// api for capture
useEffect(() => {
  if (!proposalId) return;

  const fetchData = async () => {
    try {
      const [analysisRes, captureRes] = await Promise.all([
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/proposals/${proposalId}/analysis`),
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/proposals/capture/${proposalId}`),
      ]);

      const analysisData = await analysisRes.json();
      const captureData = await captureRes.json();

      console.log("Analysis API raw:", analysisData);
      console.log("Capture API raw:", captureData);

      setAnalysisResult(analysisData?.analysis ?? null);

      const capturePayload =
        captureData?.capture ?? captureData?.data ?? captureData?.result ?? captureData;

      if (!capturePayload || Object.keys(capturePayload).length === 0) {
        console.warn("Capture API returned empty payload", captureData);
        setCaptureState(null);
      } else {
        setCaptureState(normalizeCaptureData(capturePayload) as GenerateClientProfileOutput);
      }

    } catch (error: any) {
      console.error("Fetch failed:", error);
      toast({
        variant: "destructive",
        title: "Fetch Failed",
        description: error.message ?? "Could not fetch proposal data.",
      });
      setCaptureState(null);
    }
  };

  fetchData();
}, [proposalId, toast]);



const normalizeCaptureData = (data: any) => ({
  clientProfile: {
    content: `
Mission: ${data.clientProfile?.mission ?? "N/A"}

Strategic Priorities:
- ${(data.clientProfile?.strategicPriorities ?? []).join("\n- ")}

Technology Strategy:
${data.clientProfile?.technologyStrategy ?? "N/A"}

Leadership:
${(data.clientProfile?.leadership ?? []).map(l => `${l.name} (${l.role}) - ${l.url}`).join("\n")}
    `.trim(),
    source: "AI-generated",
  },
  incumbentVendors: {
    content: (data.incumbentVendors ?? [])
      .map(v => `${v.vendor} - ${v.project} (${v.durationValue}, Performance: ${v.performance}) - ${v.url}`)
      .join("\n"),
    source: "AI-generated",
  },
  competitors: {
    content: (data.competitors ?? [])
      .map(c => `${c.firm} | Strengths: ${c.strengths} | Weaknesses: ${c.weaknesses} | Why: ${c.why}`)
      .join("\n"),
    source: "AI-generated",
  },
  gapAnalysis: {
    content: (data.gapAnalysis ?? [])
      .map(g => `${g.item} | Current: ${g.currentState} | Gap: ${g.gaps} | Future: ${g.desiredFutureState} | ${g.url}`)
      .join("\n"),
    source: "AI-generated",
  },
  stakeholders: {
    content: (data.stakeholders ?? [])
      .map(s => `${s.name} (${s.role}) - ${s.relevance} | Remarks: ${s.remarks} | ${s.url}`)
      .join("\n"),
    source: "AI-generated",
  },
  strategicTakeaways: {
    content: `
Strategic Priorities: ${(data.clientProfile?.strategicPriorities ?? []).join(", ")}
Technology Strategy: ${data.clientProfile?.technologyStrategy ?? "N/A"}
Key Gaps: ${(data.gapAnalysis ?? []).map(g => g.item).join(", ")}
    `.trim(),
    source: "AI-generated",
  },
});



//

  return (
    <Tabs defaultValue="analysis" className="w-full">
      <TabsList className="grid w-full grid-cols-3 md:grid-cols-5 h-auto">
        <TabsTrigger value="analysis" className="py-2.5">
  <TabLabel icon={FileText} label="Analysis" loading={analysisLoading} />
</TabsTrigger>

<TabsTrigger value="capture" className="py-2.5">
  <TabLabel icon={Target} label="Capture" loading={isLoading.capture} />
</TabsTrigger>

<TabsTrigger value="compliance" className="py-2.5">
  <TabLabel icon={ListChecks} label="Compliance" loading={isLoading.compliance} />
</TabsTrigger>

<TabsTrigger value="outline" className="py-2.5">
  <TabLabel icon={FileSignature} label="Outline" loading={isLoading.outline} />
</TabsTrigger>

<TabsTrigger value="draft" className="py-2.5">
  <TabLabel icon={BookMarked} label="Draft" loading={isLoading.draft} />
  {proposalDraft && !isLoading.draft && (
    <span className="ml-2 h-2 w-2 rounded-full bg-green-500"></span>
  )}
</TabsTrigger>

      </TabsList>
<TabsContent value="analysis" className="mt-6">
  <AnalysisContent
    result={analysisResult}
    isLoading={analysisLoading}
    proposalId={proposalId}  // ✅ Pass it here
  />
</TabsContent>

      <TabsContent value="capture" className="mt-6">
        <CaptureContent result={captureState} isLoading={isLoading.capture} />
      </TabsContent>
      <TabsContent value="compliance" className="mt-6">
        <ComplianceContent result={complianceMatrix} isLoading={isLoading.compliance} />
      </TabsContent>
      <TabsContent value="outline" className="mt-6">
        <OutlineContent 
            onGenerate={onGenerateDraft} 
            isLoading={isLoading.draft} 
            rfpContent={rfpContent}
            knowledgeBaseContent={knowledgeBaseContent}
        />
      </TabsContent>
      <TabsContent value="draft" className="mt-6">
        <DraftContent draft={proposalDraft} isLoading={isLoading.draft} />
      </TabsContent>
    </Tabs>
  );
}

    