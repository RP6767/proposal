// TabLabel.tsx
import { Loader2 } from 'lucide-react';
import React from 'react';

interface TabLabelProps {
  icon: React.ElementType;
  label: string;
  loading?: boolean;
}

export const TabLabel: React.FC<TabLabelProps> = ({ icon: Icon, label, loading }) => (
  <div className="flex items-center">
    <Icon className="w-4 h-4 mr-2" />
    {label}
    {loading && <Loader2 className="w-4 h-4 ml-2 animate-spin" />}
  </div>
);
