"use client";
 
import Image from "next/image";
 
export default function Logo() {
  return (
    <Image
      src="/logo.webp" // your logo in /public folder
      alt="Logo"
      width={150}
      height={100}
      priority
    />
  );
}
 