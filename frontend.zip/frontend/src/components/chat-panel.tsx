'use client';

import { useState, useRef, useEffect, type Dispatch, type SetStateAction } from 'react';
import { Bot, Loader2, Send, User } from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

export type ChatMessage = {
  role: 'user' | 'assistant';
  content: string;
};

type ChatPanelProps = {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  chatMessages: ChatMessage[];
  setChatMessages: Dispatch<SetStateAction<ChatMessage[]>>;
  proposalId: string; // <-- add this
};

export function ChatPanel({
  isOpen,
  setIsOpen,
  chatMessages,
  setChatMessages,
   proposalId,   // <-- destructure it
}: ChatPanelProps) {
  const [input, setInput] = useState('');
  const [isAnswering, setIsAnswering] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Auto scroll to bottom
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTo({
        top: scrollAreaRef.current.scrollHeight,
        behavior: 'smooth',
      });
    }
  }, [chatMessages]);

const handleSend = async () => {
  if (!input.trim() || isAnswering) return;

  const newMessages: ChatMessage[] = [
    ...chatMessages,
    { role: 'user', content: input },
  ];
  setChatMessages(newMessages);
  setInput('');
  setIsAnswering(true);

  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        proposalId: proposalId,  // pass the proposal id here
        question: input,
                 // optional extra context
      }),
    });

    if (!res.ok) throw new Error('Failed to get a reply from server');

    const data = await res.json();
    const assistantReply = data.answer ?? 'No response';

    setChatMessages([
      ...newMessages,
      { role: 'assistant', content: assistantReply },
    ]);
  } catch (err: any) {
    console.error('Chat error:', err);
    toast({
      variant: 'destructive',
      title: 'Chat Error',
      description: err.message ?? 'Something went wrong',
    });
    setChatMessages(chatMessages);
  } finally {
    setIsAnswering(false);
  }
};

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetContent className="w-full sm:max-w-2xl flex flex-col p-0">
        <SheetHeader className="p-6 pb-4">
          <SheetTitle className="flex items-center gap-2">
            <Bot /> Chat with RFP Assistant
          </SheetTitle>
        </SheetHeader>

        <ScrollArea className="flex-1 px-6" ref={scrollAreaRef}>
          <div className="space-y-6 pb-4">
            {chatMessages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground pt-20">
                <Bot className="w-12 h-12 mb-4" />
                <p className="text-lg font-medium">Welcome to the RFP Chat</p>
                <p>Ask any question about your proposal content.</p>
              </div>
            ) : (
              chatMessages.map((message) => (
                <div
                  key={message.id}
                  className={cn(
                    'flex items-start gap-3',
                    message.role === 'user' ? 'justify-end' : 'justify-start'
                  )}
                >
                  {message.role === 'assistant' && (
                    <Avatar className="w-8 h-8 border">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        <Bot className="w-5 h-5" />
                      </AvatarFallback>
                    </Avatar>
                  )}

                  <div
                    className={cn(
                      'rounded-lg p-3 max-w-[80%] text-sm',
                      message.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    )}
                  >
                    <p className="whitespace-pre-wrap">{message.content}</p>
                  </div>

                  {message.role === 'user' && (
                    <Avatar className="w-8 h-8 border">
                      <AvatarFallback>
                        <User className="w-5 h-5" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))
            )}

            {isAnswering && (
              <div className="flex items-start gap-3 justify-start">
                <Avatar className="w-8 h-8 border">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    <Bot className="w-5 h-5" />
                  </AvatarFallback>
                </Avatar>
                <div className="rounded-lg p-3 bg-muted flex items-center space-x-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm text-muted-foreground">Thinking...</span>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        <SheetFooter className="p-6 pt-4 bg-background border-t">
          <div className="relative w-full">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask about deadlines, scope, requirements..."
              className="pr-20 min-h-[52px] resize-none"
              disabled={isAnswering}
            />
            <Button
              type="submit"
              size="icon"
              onClick={handleSend}
              disabled={!input.trim() || isAnswering}
              className="absolute right-2 top-1/2 -translate-y-1/2 h-9 w-14"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
