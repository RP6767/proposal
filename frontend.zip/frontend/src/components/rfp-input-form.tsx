'use client';

import React, { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation'; // add at the to
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import * as pdfjs from 'pdfjs-dist';
import mammoth from 'mammoth';
import { nanoid } from 'nanoid';
import { FileText, Loader2, Sparkles, Upload } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Form, FormControl, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { Input } from './ui/input';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import type { AttachedDocument } from '@/lib/types';

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

const formSchema = z.object({
  proposalName: z.string().min(1, 'Proposal name is required.'),
  proposalType: z.enum(['Fed', 'SLED'], { required_error: 'You must select a proposal type.' }),
  rfpContent: z.string().optional(),
  rfpFiles: z.array(z.any()).optional(),
}).refine(data => data.rfpContent || (data.rfpFiles && data.rfpFiles.length > 0), {
  message: "Either RFP content or at least one RFP file is required.",
  path: ["rfpContent"],
});

export function RfpInputForm() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedFiles, setUploadedFiles] = useState<AttachedDocument[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState<'paste' | 'upload'>('paste');
  const [isFormValid, setIsFormValid] = useState(false);
  const router = useRouter(); 

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { proposalName: '', rfpContent: '', rfpFiles: [] },
    mode: 'onChange',
  });

  // Validate button enable/disable
  useEffect(() => {
    const subscription = form.watch((values) => {
      const valid = values.proposalName.trim() !== '' &&
                    values.proposalType &&
                    (values.rfpContent?.trim() !== '' || uploadedFiles.length > 0);
      setIsFormValid(valid);
    });
    return () => subscription.unsubscribe();
  }, [form, uploadedFiles]);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setIsProcessing(true);
    const newUploadedFiles: AttachedDocument[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      let type: AttachedDocument['type'] = 'other';
      if (file.type === 'application/pdf') type = 'pdf';
      else if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') type = 'docx';
      else if (file.type === 'text/plain') type = 'txt';

      const doc: AttachedDocument = {
        id: nanoid(),
        name: file.name,
        type,
        size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
      };

      try {
        let text = '';
        if (type === 'txt') {
          text = await file.text();
        } else if (type === 'pdf') {
          const arrayBuffer = await file.arrayBuffer();
          const pdf = await pdfjs.getDocument(arrayBuffer).promise;
          for (let p = 1; p <= pdf.numPages; p++) {
            const page = await pdf.getPage(p);
            const content = await page.getTextContent();
            text += content.items.map((item: any) => item.str).join(' ');
          }
        } else if (type === 'docx') {
          const arrayBuffer = await file.arrayBuffer();
          const result = await mammoth.extractRawText({ arrayBuffer });
          text = result.value;
        }
        doc.textContent = text;
        newUploadedFiles.push(doc);
      } catch (err) {
        toast({
          variant: 'destructive',
          title: 'File Processing Error',
          description: `Unable to read file: ${file.name}`,
        });
      }
    }

    setUploadedFiles(newUploadedFiles);
    form.setValue('rfpFiles', newUploadedFiles);

    if (!form.getValues('proposalName') && newUploadedFiles.length > 0) {
      form.setValue('proposalName', newUploadedFiles[0].name.replace(/\.[^/.]+$/, ''));
    }

    setIsProcessing(false);
  };

  const handleFormSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsProcessing(true);
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL;
      if (!apiUrl) throw new Error('API URL not defined');

      const combinedContent =
        values.rfpContent || uploadedFiles.map(f => f.textContent || '').join('\n');

const payload = {
  proposal_name: values.proposalName,
  type: values.proposalType,
  content: combinedContent,
  files: uploadedFiles.map(f => ({ name: f.name, type: f.type, textContent: f.textContent })),
};


      const res = await fetch(`${apiUrl}/api/proposals`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create proposal');

      toast({
        title: 'Proposal Created!',
        description: `Proposal "${data.name}" has been saved successfully.`,
      });

      form.reset();
      setUploadedFiles([]);
      if (fileInputRef.current) fileInputRef.current.value = '';
    router.push(`/proposal/${data.id}`); // assuming your API returns `id` of the created proposal
    } catch (err: any) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: err.message || 'Something went wrong',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleTabChange = (tab: 'paste' | 'upload') => {
    setActiveTab(tab);
    setUploadedFiles([]);
    form.setValue('rfpContent', '');
    form.setValue('rfpFiles', []);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <Card className="w-full max-w-3xl shadow-lg">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleFormSubmit)}>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-md bg-primary/10">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <div>
                <CardTitle>Start a New Proposal</CardTitle>
                <CardDescription>
                  Provide proposal details, then paste your RFP content or upload one or more documents to begin.
                </CardDescription>
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Name and Type in One Row */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormItem>
                <FormLabel>Proposal Name</FormLabel>
                <FormControl>
                  <Input {...form.register('proposalName')} placeholder="e.g., Project Phoenix RFP" />
                </FormControl>
                <FormMessage>{form.formState.errors.proposalName?.message}</FormMessage>
              </FormItem>

              <FormItem>
                <FormLabel>Proposal Type</FormLabel>
                <Controller
                  control={form.control}
                  name="proposalType"
                  render={({ field }) => (
                    <Select value={field.value} onValueChange={field.onChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select Fed or SLED" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Fed">Fed (Federal)</SelectItem>
                        <SelectItem value="SLED">SLED (State, Local, Education)</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                />
                <FormMessage>{form.formState.errors.proposalType?.message}</FormMessage>
              </FormItem>
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={handleTabChange}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="paste">Paste Content</TabsTrigger>
                <TabsTrigger value="upload">Upload File(s)</TabsTrigger>
              </TabsList>

              <TabsContent value="paste" className="pt-4">
                <FormItem>
                  <FormControl>
                    <Textarea
                      placeholder="Paste your full RFP document text here..."
                      className="min-h-[300px] text-base"
                      {...form.register('rfpContent')}
                    />
                  </FormControl>
                  <FormMessage>{form.formState.errors.rfpContent?.message}</FormMessage>
                </FormItem>
              </TabsContent>

              <TabsContent value="upload" className="pt-4">
                <div className="flex flex-col gap-3">
                  <label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer bg-muted/50 hover:bg-muted">
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                      {uploadedFiles.length > 0 ? (
                        uploadedFiles.map(f => (
                          <p key={f.id} className="font-semibold text-primary">{f.name}</p>
                        ))
                      ) : (
                        <>
                          <Upload className="w-8 h-8 mb-4 text-muted-foreground" />
                          <p className="mb-2 text-sm text-muted-foreground">
                            <span className="font-semibold">Click to upload</span> or drag and drop
                          </p>
                          <p className="text-xs text-muted-foreground">TXT, PDF, DOCX</p>
                        </>
                      )}
                    </div>
                    <Input
                      id="dropzone-file"
                      type="file"
                      className="hidden"
                      accept=".txt,.pdf,.docx"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      multiple
                    />
                  </label>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>

          <CardFooter className="flex justify-end">
            <Button type="submit" disabled={!isFormValid || isProcessing} size="lg">
              {isProcessing ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Sparkles className="w-5 h-5 mr-2" />}
              Start Analysis
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
