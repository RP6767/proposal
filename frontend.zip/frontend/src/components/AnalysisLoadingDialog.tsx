'use client';

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";

export function AnalysisLoadingDialog({ open }: { open: boolean }) {
  return (
    <Dialog open={open}>
      <DialogContent className="flex flex-col items-center justify-center space-y-4">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <DialogHeader>
          <DialogTitle>Analyzing documents…</DialogTitle>
          <p className="text-sm text-muted-foreground">
            Our AI is updating the proposal analysis. This may take a moment.
          </p>
        </DialogHeader>
      </DialogContent>
    </Dialog>
  );
}
