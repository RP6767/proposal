export interface Proposal {
  id: string;
  name: string;
  status: 'In Progress' | 'Completed';
  lastUpdated: string;
  user: string;
  type: 'Fed' | 'SLED';
}
