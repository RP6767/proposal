
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { PlusCircle, FileText, BookText, Eye, Pencil, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { nanoid } from 'nanoid';

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import Logo from '@/components/logo';
import type { Proposal } from '@/types/proposal';
import { cn } from '@/lib/utils';
import { ProposalType } from '@/lib/types';

type FilterStatus = 'All' | 'In Progress' | 'Completed';
type FilterType = 'All' | ProposalType;

export default function Dashboard() {
  const router = useRouter();

  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<FilterStatus>('All');
  const [typeFilter, setTypeFilter] = useState<FilterType>('All');

  // 🔹 Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 5;

  // 🔹 Fetch proposals
  useEffect(() => {
    const fetchProposals = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/proposals`);
        if (!res.ok) throw new Error("Failed to fetch proposals");
        const data = await res.json();
        setProposals(data);
      } catch (err) {
        console.error("Error fetching proposals:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchProposals();
  }, []);

  // 🔹 Delete proposal
  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this proposal?")) return;
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/proposals/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete proposal");
      setProposals(prev => prev.filter(p => p.id !== id));
    } catch (err) {
      console.error("Error deleting proposal:", err);
      alert("Failed to delete proposal");
    }
  };

  // 🔹 Filters
  const filteredProposals = proposals.filter(p => {
    const statusMatch = statusFilter === 'All' || p.status === statusFilter;
    const typeMatch = typeFilter === 'All' || p.type === typeFilter;
    return statusMatch && typeMatch;
  });

  // 🔹 Pagination logic
  const totalPages = Math.ceil(filteredProposals.length / rowsPerPage);
  const startIdx = (currentPage - 1) * rowsPerPage;
  const endIdx = Math.min(startIdx + rowsPerPage, filteredProposals.length);
  const paginatedProposals = filteredProposals.slice(startIdx, endIdx);

  const handleNewProposal = () => {
    const newProposalId = nanoid(10);
    router.push(`/proposal/${newProposalId}?new=true`);
  };

  const navigateToProposal = (id: string, name: string) => {
    router.push(`/proposal/${id}?name=${encodeURIComponent(name)}`);
  };

  // 🔹 Table rows
  const renderTableRows = () => {
    if (loading) {
      return (
        <TableRow>
          <TableCell colSpan={6} className="text-center h-24 text-muted-foreground">
            Loading proposals...
          </TableCell>
        </TableRow>
      );
    }

    if (paginatedProposals.length === 0) {
      return (
        <TableRow>
          <TableCell colSpan={6} className="text-center h-24 text-muted-foreground">
            No proposals match the current filters.
          </TableCell>
        </TableRow>
      );
    }

    return paginatedProposals.map(prop => (
      <TableRow
        key={prop.id}
        className="cursor-pointer"
        onClick={() => navigateToProposal(prop.id, prop.name)}
      >
        <TableCell className="font-medium">{prop.name}</TableCell>
        <TableCell>
          <Badge variant={prop.type === 'Fed' ? 'default' : 'secondary'}>
            {prop.type}
          </Badge>
        </TableCell>
        <TableCell>{prop.user}</TableCell>
        <TableCell>
          <Badge variant={prop.status === 'Completed' ? 'outline' : 'default'}>
            {prop.status}
          </Badge>
        </TableCell>
        <TableCell>{prop.lastUpdated}</TableCell>
        <TableCell className="text-center flex justify-center gap-2">
          {/* View */}
          <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); navigateToProposal(prop.id, prop.name); }}>
            <Eye className="w-4 h-4" />
          </Button>
          {/* Edit */}
          <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); navigateToProposal(prop.id, prop.name); }}>
            <Pencil className="w-4 h-4" />
          </Button>
          {/* Delete (no background, red on hover) */}
          <Button
            variant="ghost"
            size="icon"
  onClick={(e) => {
    e.stopPropagation();
    handleDelete(prop.id);
  }}
>
  <Trash2 className="w-4 h-4 text-black" />
          </Button>
        </TableCell>
      </TableRow>
    ));
  };

  const ProposalTable = () => (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Proposal Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Owner Name</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Last Updated</TableHead>
              <TableHead className="text-center">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>{renderTableRows()}</TableBody>
        </Table>

        {/* 🔹 Pagination */}
        <div className="flex justify-between items-center p-4 border-t">
          {/* Left: Showing X–Y of Z */}
          <span className="text-sm text-muted-foreground">
            Showing {startIdx + 1}–{endIdx} of {filteredProposals.length}
          </span>

          {/* Right: Page numbers */}
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => prev - 1)}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>

            {[...Array(totalPages)].map((_, idx) => {
              const page = idx + 1;
              return (
                <Button
                  key={page}
                  variant={currentPage === page ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(page)}
                >
                  {page}
                </Button>
              );
            })}

            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(prev => prev + 1)}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-10 flex items-center justify-between p-4 bg-background/80 backdrop-blur-sm border-b">
        <div className="flex items-center gap-3">
          <Logo />
          <h1 className="text-xl font-bold tracking-tighter">vTech Proposal Agent</h1>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => router.push('/knowledge-base')}>
            <BookText className="w-4 h-4 mr-2" />
            Knowledge Base
          </Button>
          <Button onClick={handleNewProposal}>
            <PlusCircle className="w-4 h-4 mr-2" />
            New Proposal
          </Button>
        </div>
      </header>

      <main className="flex-1 w-full max-w-7xl mx-auto p-4 md:p-8">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <h2 className="text-2xl font-bold flex items-center gap-3">
            <FileText className="text-primary" />
            All Proposals
          </h2>
          <div className="flex items-center gap-4">
            {/* Filters */}
            <div className="flex items-center gap-2 p-1 rounded-md bg-muted">
              {(['All', 'Fed', 'SLED'] as FilterType[]).map(type => (
                <Button
                  key={type}
                  variant={typeFilter === type ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setTypeFilter(type)}
                  className={cn("w-24", typeFilter === type && 'shadow-sm bg-background text-foreground hover:bg-background/80')}
                >
                  {type}
                </Button>
              ))}
            </div>
            <div className="flex items-center gap-2 p-1 rounded-md bg-muted">
              {(['All', 'In Progress', 'Completed'] as FilterStatus[]).map(status => (
                <Button
                  key={status}
                  variant={statusFilter === status ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setStatusFilter(status)}
                  className={cn("w-28", statusFilter === status && 'shadow-sm bg-background text-foreground hover:bg-background/80')}
                >
                  {status}
                </Button>
              ))}
            </div>
          </div>
        </div>

        <ProposalTable />
      </main>
    </div>
  );
}
