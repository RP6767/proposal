'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  BookText, ChevronLeft, Plus, Trash2, Upload, File, Link, Type, Eye
} from 'lucide-react';
import * as pdfjs from 'pdfjs-dist';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Logo from '@/components/logo';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle} from '@/components/ui/dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';

import type { KnowledgeCategory, KnowledgeItem } from '@/lib/types';

pdfjs.GlobalWorkerOptions.workerSrc =
  `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

const getIconForType = (type: KnowledgeItem['type']) => {
  switch (type) {
    case 'manual': return <Type className="w-4 h-4 text-muted-foreground" />;
    case 'file': return <File className="w-4 h-4 text-muted-foreground" />;
    case 'url': return <Link className="w-4 h-4 text-muted-foreground" />;
    default: return <BookText className="w-4 h-4 text-muted-foreground" />;
  }
};

const getCategoryBadgeVariant = (category: KnowledgeCategory) => {
  switch (category) {
    case 'Fed': return 'default';
    case 'SLED': return 'secondary';
    case 'General': return 'outline';
    default: return 'outline';
  }
};

const trimContent = (text?: string) => {
  if (!text) return '';
  const words = text.split(' ');
  return words.slice(0, 15).join(' ') + (words.length > 15 ? '...' : '');
};

export default function KnowledgeBasePage() {
  const router = useRouter();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [knowledgeBase, setKnowledgeBase] = useState<KnowledgeItem[]>([]);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [newItem, setNewItem] = useState('');
  const [url, setUrl] = useState('');
  const [isFetchingUrl, setIsFetchingUrl] = useState(false);
  const [currentCategory, setCurrentCategory] = useState<KnowledgeCategory>('General');
  const [viewContent, setViewContent] = useState<string | null>(null);

  const fetchKnowledgeBase = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/knowledge`);
      if (!res.ok) throw new Error('Failed to fetch knowledge base');
      const data = await res.json();
      setKnowledgeBase(data);
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    }
  };

  useEffect(() => { fetchKnowledgeBase(); }, []);

  const handleAddItem = async () => {
    if (!newItem.trim()) return;
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/knowledge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: newItem,
          type: 'manual',
          category: currentCategory,
          source: 'manual input',
        }),
      });
      if (!res.ok) throw new Error('Failed to add item');
      const added = await res.json();
      setKnowledgeBase(prev => [added, ...prev]);
      setNewItem('');
      toast({ title: 'Knowledge Base updated', description: 'New information has been added.' });
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    }
  };

  const handleRemoveItem = async (id: string) => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/knowledge/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Failed to delete item');
      setKnowledgeBase(prev => prev.filter(item => item.id !== id));
      setSelectedItems(prev => prev.filter(i => i !== id));
      toast({ title: 'Item removed', description: 'The selected item has been removed.' });
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    }
  };

  const handleBulkDelete = async () => {
    if (!selectedItems.length) return;
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/knowledge/bulk-delete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: selectedItems }),
      });
      if (!res.ok) throw new Error('Failed to delete items');
      setKnowledgeBase(prev => prev.filter(item => !selectedItems.includes(item.id)));
      setSelectedItems([]);
      toast({ title: 'Deleted', description: `${selectedItems.length} items deleted.` });
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;
    const formData = new FormData();
    Array.from(files).forEach(file => formData.append('files', file));
    formData.append('category', currentCategory);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/knowledge`, {
        method: 'POST', body: formData,
      });
      if (!res.ok) throw new Error('Failed to upload files');
      const data = await res.json();
      toast({ title: 'Upload complete', description: data.message });
      fetchKnowledgeBase();
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    }
  };

  const handleAddUrl = async () => {
    if (!url.trim()) return;
    setIsFetchingUrl(true);
    try {
      const formData = new FormData();
      formData.append('url', url);
      formData.append('category', currentCategory);
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/knowledge`, {
        method: 'POST', body: formData,
      });
      if (!res.ok) throw new Error('Failed to fetch URL content');
      const data = await res.json();
      toast({ title: 'URL Content Added', description: data.message ?? 'Content added successfully.' });
      setUrl('');
      fetchKnowledgeBase();
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    } finally {
      setIsFetchingUrl(false);
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedItems(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const AddDataFooter = ({ onAdd }: { onAdd?: () => void }) => (
    <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-4 border-t mt-4">
      <RadioGroup
        value={currentCategory}
        onValueChange={(value: KnowledgeCategory) => setCurrentCategory(value)}
        className="flex items-center gap-4"
      >
        <Label className="font-semibold">Category:</Label>
        <div className="flex items-center space-x-2"><RadioGroupItem value="Fed" id="r-fed" /><Label htmlFor="r-fed">Fed</Label></div>
        <div className="flex items-center space-x-2"><RadioGroupItem value="SLED" id="r-sled" /><Label htmlFor="r-sled">SLED</Label></div>
        <div className="flex items-center space-x-2"><RadioGroupItem value="General" id="r-general" /><Label htmlFor="r-general">General</Label></div>
      </RadioGroup>
      {onAdd && (
        <Button onClick={onAdd}>
          <Plus className="w-4 h-4 mr-2" /> Add to Knowledge Base
        </Button>
      )}
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-10 flex items-center justify-between p-4 bg-background/80 backdrop-blur-sm border-b">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.push('/')} className="h-8 w-8"><ChevronLeft className="w-5 h-5" /></Button>
          <Logo />
          <h1 className="text-xl font-bold tracking-tighter">vTech Proposal Agent</h1>
        </div>
      </header>

      <main className="flex-1 w-full max-w-5xl mx-auto p-4 md:p-8">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-4">
              <BookText className="w-8 h-8 text-primary" />
              <div>
                <CardTitle className="text-2xl">Knowledge Base</CardTitle>
                <CardDescription>Manage company boilerplate data for Fed, SLED, and General use.</CardDescription>
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-lg font-semibold">Current Data</h3>
                {selectedItems.length > 0 && (
                  <Button variant="destructive" size="sm" onClick={handleBulkDelete}>
                    Delete {selectedItems.length} Selected
                  </Button>
                )}
              </div>

              {knowledgeBase.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                     
                     
                      <TableHead>Source</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead className="text-center">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {knowledgeBase.map(item => (
                      <TableRow key={item.id}>
                        
                        
                        <TableCell>{item.source}</TableCell>
                        <TableCell>
                          <Badge variant={getCategoryBadgeVariant(item.category)}>{item.category}</Badge>
                        </TableCell>
                        <TableCell className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => { setViewContent(item.content); setIsOpen(true); }}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <button><input
                            type="checkbox"
                            className="w-4 h-4"
                            checked={selectedItems.includes(item.id)}
                            onChange={() => toggleSelect(item.id)}
                          /></button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-muted-foreground hover:text-destructive"
                            onClick={() => handleRemoveItem(item.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center text-muted-foreground py-8 border-2 border-dashed rounded-lg">
                  <p>Your Knowledge Base is empty.</p>
                  <p className="text-sm">Add data manually, upload files, or import from a URL.</p>
                </div>
              )}
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Add New Data</h3>
              <Tabs defaultValue="paste" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="paste"><Type className="w-4 h-4 mr-2" /> Paste Text</TabsTrigger>
                  <TabsTrigger value="upload"><Upload className="w-4 h-4 mr-2" /> Upload Files</TabsTrigger>
                  <TabsTrigger value="url"><Link className="w-4 h-4 mr-2" /> From URL</TabsTrigger>
                </TabsList>

                <TabsContent value="paste" className="pt-4">
                  <div className="space-y-2">
                    <Textarea
                      id="new-kb-item"
                      placeholder="Add text..."
                      value={newItem}
                      onChange={e => setNewItem(e.target.value)}
                      className="min-h-[150px]"
                    />
                    <AddDataFooter onAdd={handleAddItem} />
                  </div>
                </TabsContent>

                <TabsContent value="upload" className="pt-4">
                  <div className="space-y-2">
                    <label htmlFor="kb-file-upload" className="sr-only">Upload documents</label>
                    <div className="flex items-center justify-center w-full">
                      <label
                        htmlFor="kb-file-upload"
                        className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-muted/50 hover:bg-muted"
                      >
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <Upload className="w-8 h-8 mb-4 text-muted-foreground" />
                          <p className="mb-2 text-sm text-muted-foreground"><span className="font-semibold">Click to upload</span></p>
                          <p className="text-xs text-muted-foreground">Multiple TXT, PDF, DOCX files</p>
                        </div>
                        <Input id="kb-file-upload" type="file" className="hidden" onChange={handleFileUpload} multiple accept=".txt,.pdf,.docx" />
                      </label>
                    </div>
                    <AddDataFooter />
                  </div>
                </TabsContent>

                <TabsContent value="url" className="pt-4">
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <Input
                        id="url-input"
                        placeholder="https://example.com"
                        value={url}
                        onChange={e => setUrl(e.target.value)}
                        disabled={isFetchingUrl}
                      />
                      <Button onClick={handleAddUrl} disabled={isFetchingUrl ?? !url.trim()}>
                        {isFetchingUrl ? 'Fetching...' : 'Fetch Content'}
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">Note: Web page scraping may not work for all sites.</p>
                    <AddDataFooter />
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Full Content Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Full Content</DialogTitle></DialogHeader>
          <p className="whitespace-pre-wrap">{viewContent}</p>
          <div className="flex justify-end mt-4">
            <Button variant="outline" onClick={() => setIsOpen(false)}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
