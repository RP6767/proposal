'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { MessageSquare, ChevronLeft } from 'lucide-react';
import type {
  AnalyzeRFPContentOutput,
  GenerateClientProfileOutput,
  DraftProposalSectionsOutput,
  GenerateComplianceMatrixOutput,
  ChatMessage,
  KnowledgeItem,
  ProposalType,
  AttachedDocument,
} from '@/lib/types';

import { Button } from '@/components/ui/button';
import { RfpInputForm } from '@/components/rfp-input-form';
import { ResultsDisplay } from '@/components/results-display';
import { ChatPanel } from '@/components/chat-panel';
import Logo from '@/components/logo';
import { useToast } from '@/hooks/use-toast';
import { MOCK_KB_CONTENT } from '@/lib/mock-data';
import { AttachedDocuments } from '@/components/attached-documents';

// ---------------- Types ----------------
type LoadingStates = {
  analysis: boolean;
  capture: boolean;
  outline: boolean;
  draft: boolean;
  compliance: boolean;
};

// ---------------- Retry helper ----------------
async function retry<T>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
  let lastError: Error | undefined;
  for (let i = 0; i < retries; i++) {
    try {
      return await fn();
    } catch (error: unknown) {
      lastError = error as Error;
      if (lastError?.message?.includes('503')) {
        console.warn(`Attempt ${i + 1} failed with 503. Retrying in ${delay}ms...`);
        await new Promise(res => setTimeout(res, delay));
      } else {
        throw lastError;
      }
    }
  }
  throw lastError;
}

// ---------------- Component ----------------
interface Props {
  proposalId: string;
}

export default function ProposalPageClient({ proposalId }: Readonly<Props>) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const name = searchParams.get('name') ?? 'Unnamed Proposal';
  const isNew = searchParams.get('new') === 'true';

  // State
  const [proposalName, setProposalName] = useState<string>('');
  const [rfpContent, setRfpContent] = useState<string>('');
  const [isRfpSubmitted, setIsRfpSubmitted] = useState<boolean>(false);
  const [loading, setLoading] = useState<LoadingStates>({
    analysis: false,
    capture: false,
    outline: false,
    draft: false,
    compliance: false,
  });

  const [knowledgeBase] = useState<KnowledgeItem[]>(MOCK_KB_CONTENT);
  const [relevantKb, setRelevantKb] = useState<string>('');

  const [analysisResult, setAnalysisResult] = useState<AnalyzeRFPContentOutput | null>(null);
  const [captureResult, setCaptureResult] = useState<GenerateClientProfileOutput | null>(null);
  const [proposalDraft, setProposalDraft] = useState<DraftProposalSectionsOutput | null>(null);
  const [complianceMatrix, setComplianceMatrix] = useState<GenerateComplianceMatrixOutput | null>(null);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isChatOpen, setIsChatOpen] = useState(false);

  const [attachedDocs, setAttachedDocs] = useState<AttachedDocument[]>([]);

  const { toast } = useToast();

// ---------------- Load proposal ----------------
useEffect(() => {
  const fetchProposal = async () => {
    if (isNew) {
      setProposalName('New Proposal');
      setIsRfpSubmitted(false);
      setAttachedDocs([]);
      setRfpContent('');
    } else {
      try {
        const apiUrl = process.env.NEXT_PUBLIC_API_URL;
        if (!apiUrl) throw new Error('API URL not defined');

        const res = await fetch(`${apiUrl}/api/proposals/${proposalId}`);
        if (!res.ok) throw new Error('Failed to fetch proposal');

        const data = await res.json();

        setProposalName(data.name ?? `Proposal ${name}`);
        setRfpContent(data.content ?? '');
        setIsRfpSubmitted(true);

        // Map backend files to state
        if (Array.isArray(data.files) && data.files.length > 0) {
          const files: AttachedDocument[] = data.files.map((f: any) => ({
            id: f.id ?? f.name,
            name: f.name,
            type: f.type,
            textContent: f.textContent ?? '',
            size: f.size ?? undefined,
          }));
          setAttachedDocs(files);
        } else {
          setAttachedDocs([]);
        }

        // Knowledge base setup
        const filteredKb = knowledgeBase.filter(
          item => item.category === 'General' || item.category === data.type
        );
        const kbContent = filteredKb.map(item => item.content).join('\n\n');
        setRelevantKb(kbContent);
      } catch (err: any) {
        toast({
          variant: 'destructive',
          title: 'Error fetching proposal',
          description: err.message ?? 'Something went wrong',
        });
      }
    }
  };

  fetchProposal();
}, [proposalId, isNew, name, knowledgeBase, toast]);

// ---------------- Listen for analysisUpdated ----------------
useEffect(() => {
  const handleAnalysisUpdate = (event: Event) => {
    const customEvent = event as CustomEvent<any>;
    if (customEvent.detail) {
      setAnalysisResult(customEvent.detail); // update analysis directly
    }
  };

  document.addEventListener("analysisUpdated", handleAnalysisUpdate);

  return () => {
    document.removeEventListener("analysisUpdated", handleAnalysisUpdate);
  };
}, []);


  // ---------------- Submit RFP ----------------
  const handleRfpSubmit = (
    content: string,
    name: string,
    type: ProposalType,
    initialDocs?: AttachedDocument[]
  ) => {
    setRfpContent(content);
    setProposalName(name);
    if (initialDocs) setAttachedDocs(initialDocs);

    const filteredKb = knowledgeBase.filter(item => item.category === 'General' || item.category === type);
    const kbContent = filteredKb.map(item => item.content).join('\n\n');
    setRelevantKb(kbContent);

    setIsRfpSubmitted(true);
    triggerAnalysisAndCapture(content, kbContent);
  };

  // ---------------- Run analysis ----------------
  const triggerAnalysisAndCapture = async (content: string, kbContent: string) => {
    setLoading({ analysis: true, capture: true, compliance: true, outline: true, draft: false });
    setAnalysisResult(null);
    setCaptureResult(null);
    setComplianceMatrix(null);
    setProposalDraft(null);
    setChatMessages([]);

    try {
      const [analysis, capture, compliance] = await Promise.all([
        retry(() => analyzeRFPContent({ rfpContent: content, knowledgeBaseContent: kbContent })),
        retry(() => generateClientProfile({ rfpContent: content, knowledgeBaseContent: kbContent })),
        retry(() => generateComplianceMatrix({ rfpContent: content, knowledgeBaseContent: kbContent })),
      ]);
      setAnalysisResult(analysis);
      setCaptureResult(capture);
      setComplianceMatrix(compliance);
    } catch (error) {
      console.error('Error during initial analysis:', error);
      toast({
        variant: 'destructive',
        title: 'Analysis Failed',
        description: 'There was an error processing the RFP content. Please try again.',
      });
    } finally {
      setLoading(prev => ({ ...prev, analysis: false, capture: false, compliance: false, outline: false }));
    }
  };

  // ---------------- Generate draft ----------------
  const handleGenerateDraft = async (proposalOutline: string) => {
    setLoading(prev => ({ ...prev, draft: true }));
    setProposalDraft(null);

    try {
      const draft = await retry(() =>
        draftProposalSections({
          rfpContent,
          proposalOutline,
          knowledgeBaseContent: relevantKb,
        })
      );
      setProposalDraft(draft);
    } catch (error) {
      console.error('Error generating proposal draft:', error);
      toast({
        variant: 'destructive',
        title: 'Draft Generation Failed',
        description: 'Could not generate the proposal draft. Please try again.',
      });
    } finally {
      setLoading(prev => ({ ...prev, draft: false }));
    }
  };

  // ---------------- Render ----------------
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-10 flex items-center justify-between p-4 bg-background/80 backdrop-blur-sm border-b">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.push('/')} className="h-8 w-8">
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <Logo />
          <h1 className="text-xl font-semibold tracking-tighter">{proposalName}</h1>
        </div>
        {isRfpSubmitted && (
          <div className="flex items-center gap-4">
            <Button onClick={() => setIsChatOpen(true)}>
              <MessageSquare className="w-4 h-4 mr-2" />
              Chat with RFP
            </Button>
          </div>
        )}
      </header>

      {/* Main content */}
      <main
        className={`flex-1 w-full mx-auto p-4 md:p-8 transition-all duration-300 ${
          !isRfpSubmitted ? 'flex items-center justify-center max-w-6xl' : ''
        }`}
      >
        {!isRfpSubmitted ? (
          <RfpInputForm
            onSubmit={handleRfpSubmit}
            isProcessing={loading.analysis ?? loading.capture ?? loading.compliance}
          />
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 w-full max-w-screen-2xl mx-auto">
            <div className="xl:col-span-8 2xl:col-span-9">
              <ResultsDisplay
                proposalId={proposalId}
                analysisResult={analysisResult}
                captureResult={captureResult}
                proposalDraft={proposalDraft}
                complianceMatrix={complianceMatrix}
                onGenerateDraft={handleGenerateDraft}
                isLoading={loading}
                rfpContent={rfpContent}
                knowledgeBaseContent={relevantKb}
              />
            </div>
            <div className="xl:col-span-4 2xl:col-span-3">
              <AttachedDocuments docs={attachedDocs} setDocs={setAttachedDocs} proposalId={proposalId} />
            </div>
          </div>
        )}
      </main>

      {/* Chat */}
      <ChatPanel
        isOpen={isChatOpen}
        setIsOpen={setIsChatOpen}
        chatMessages={chatMessages}
        setChatMessages={setChatMessages}
        proposalId={proposalId}
      />
    </div>
  );
}
