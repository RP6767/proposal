import ProposalPageClient from './ProposalPageClient';

export default async function ProposalPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;

  return <ProposalPageClient proposalId={id} />;
}
