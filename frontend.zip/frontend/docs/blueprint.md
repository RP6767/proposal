# **App Name**: PropAid

## Core Features:

- RFP Content Upload: Upload RFP documents (PDF, DOCX, TXT) or paste RFP text, saving the files to Firebase Storage.
- CrewAI Proposal Builder Trigger: Initiate the CrewAI proposal builder flow upon user action, sending the extracted RFP content to a Firebase Cloud Function.
- AI-Powered Analyzer Tool: Analyze the proposal based on scope, requirements and deadlines to populate results.
- AI-Powered Capture Tool: Use provided documents to generate the client profile, incumbents, competitors and pain points for the company requiring the proposal
- AI-Powered Proposal Generator: After outline approval, use generative AI to draft the proposal sections including executive summary, techincal approach, management approach, past performance, and appendices
- Tabular Results Display: Display the results from the AI-powered proposal builder in an easy-to-navigate tabbed interface including analysis, capture, proposal outline, and a full proposal draft.
- Dynamic Chat Panel: Allow users to ask questions and receive AI-driven answers based on the uploaded RFP content, with chat history stored in Firestore.

## Style Guidelines:

- Primary color: A deep teal (#008080) for a sense of reliability.
- Background color: A very light teal (#F0FFFF) to complement the primary color.
- Accent color: A muted green (#90EE90) to give a signal to actionable items.
- Font: 'Inter', a sans-serif font suitable for body text.
- Use simple, clear icons from Material Design to represent actions and data types.
- Employ a clean, tabbed layout for easy navigation between the different proposal stages.
- Use a subtle loading animation during AI processing to indicate activity.